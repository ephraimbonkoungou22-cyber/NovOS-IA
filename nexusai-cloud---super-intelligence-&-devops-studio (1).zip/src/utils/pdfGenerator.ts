import { jsPDF } from 'jspdf';
import { GeneratedPdfDoc } from '../types';

export function buildPdfDocument(docData: GeneratedPdfDoc): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;

  // Color schemes
  const themes = {
    blue: {
      primary: [14, 116, 144] as [number, number, number],
      secondary: [30, 41, 59] as [number, number, number],
      accent: [6, 182, 212] as [number, number, number],
      bgBox: [240, 249, 255] as [number, number, number],
      boxBorder: [186, 230, 253] as [number, number, number],
    },
    emerald: {
      primary: [4, 120, 87] as [number, number, number],
      secondary: [24, 48, 38] as [number, number, number],
      accent: [16, 185, 129] as [number, number, number],
      bgBox: [236, 253, 245] as [number, number, number],
      boxBorder: [167, 243, 208] as [number, number, number],
    },
    carbon: {
      primary: [39, 39, 42] as [number, number, number],
      secondary: [24, 24, 27] as [number, number, number],
      accent: [99, 102, 241] as [number, number, number],
      bgBox: [244, 244, 245] as [number, number, number],
      boxBorder: [212, 212, 216] as [number, number, number],
    },
    purple: {
      primary: [109, 40, 217] as [number, number, number],
      secondary: [46, 16, 101] as [number, number, number],
      accent: [168, 85, 247] as [number, number, number],
      bgBox: [250, 245, 255] as [number, number, number],
      boxBorder: [233, 213, 255] as [number, number, number],
    },
  };

  const palette = themes[docData.themeColor || 'blue'] || themes.blue;

  let y = margin;

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - margin - 15) {
      doc.addPage();
      y = margin;
      drawPageHeader();
    }
  };

  const drawPageHeader = () => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(140, 140, 140);
    doc.text(`NexusAI Intelligence - ${docData.category || 'Document Officiel'}`, margin, 12);
    doc.text(docData.date || new Date().toISOString().split('T')[0], pageWidth - margin, 12, { align: 'right' });
    doc.setDrawColor(220, 220, 220);
    doc.setLineWidth(0.3);
    doc.line(margin, 14, pageWidth - margin, 14);
  };

  // First page banner
  doc.setFillColor(...palette.primary);
  doc.rect(margin, y, contentWidth, 8, 'F');
  y += 15;

  // Category Tag
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(...palette.accent);
  doc.text((docData.category || 'DOCUMENT ACADÉMIQUE & TECHNIQUE').toUpperCase(), margin, y);
  y += 8;

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(...palette.secondary);
  const titleLines = doc.splitTextToSize(docData.title, contentWidth);
  doc.text(titleLines, margin, y);
  y += titleLines.length * 9;

  // Subtitle
  if (docData.subtitle) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(11);
    doc.setTextColor(100, 116, 139);
    const subLines = doc.splitTextToSize(docData.subtitle, contentWidth);
    doc.text(subLines, margin, y);
    y += subLines.length * 6 + 4;
  }

  // Meta row (Author & Date)
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(120, 120, 120);
  doc.text(`Rédigé par : ${docData.author || 'NexusAI Studio'} | Date : ${docData.date || new Date().toLocaleDateString('fr-FR')}`, margin, y);
  y += 4;

  // Separator line
  doc.setDrawColor(...palette.primary);
  doc.setLineWidth(0.8);
  doc.line(margin, y, margin + 40, y);
  y += 8;

  // Abstract / Résumé Exécutif
  if (docData.abstract) {
    checkPageBreak(30);
    doc.setFillColor(...palette.bgBox);
    doc.setDrawColor(...palette.boxBorder);
    doc.setLineWidth(0.5);

    const abstractLines = doc.splitTextToSize(docData.abstract, contentWidth - 12);
    const boxHeight = abstractLines.length * 5 + 10;
    doc.roundedRect(margin, y, contentWidth, boxHeight, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(...palette.primary);
    doc.text('RÉSUMÉ EXÉCUTIF', margin + 6, y + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(51, 65, 85);
    doc.text(abstractLines, margin + 6, y + 12);
    y += boxHeight + 10;
  }

  // Sections
  docData.sections.forEach((sec, idx) => {
    checkPageBreak(35);

    // Section Heading
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(...palette.primary);
    doc.text(sec.heading || `Section ${idx + 1}`, margin, y);
    y += 7;

    // Section Content Paragraph
    if (sec.content) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      const contentLines = doc.splitTextToSize(sec.content, contentWidth);
      checkPageBreak(contentLines.length * 5 + 5);
      doc.text(contentLines, margin, y);
      y += contentLines.length * 5 + 4;
    }

    // Bullets
    if (sec.bullets && sec.bullets.length > 0) {
      sec.bullets.forEach((bullet) => {
        const bulletLines = doc.splitTextToSize(bullet, contentWidth - 8);
        checkPageBreak(bulletLines.length * 5 + 3);

        doc.setFillColor(...palette.accent);
        doc.circle(margin + 2, y - 1, 1, 'F');

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9.5);
        doc.setTextColor(51, 65, 85);
        doc.text(bulletLines, margin + 7, y);
        y += bulletLines.length * 5 + 2;
      });
      y += 3;
    }

    // Callout Box
    if (sec.callout) {
      const calloutLines = doc.splitTextToSize(sec.callout, contentWidth - 14);
      const calloutHeight = calloutLines.length * 5 + 8;
      checkPageBreak(calloutHeight + 4);

      doc.setFillColor(...palette.bgBox);
      doc.setDrawColor(...palette.boxBorder);
      doc.setLineWidth(0.5);
      doc.roundedRect(margin, y, contentWidth, calloutHeight, 1.5, 1.5, 'FD');

      doc.setFillColor(...palette.primary);
      doc.rect(margin, y, 3, calloutHeight, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(...palette.primary);
      doc.text(calloutLines, margin + 7, y + 6);
      y += calloutHeight + 6;
    }

    // Table
    if (sec.table && sec.table.headers.length > 0 && sec.table.rows.length > 0) {
      checkPageBreak(30);
      const colCount = sec.table.headers.length;
      const colWidth = contentWidth / colCount;

      // Table Header
      doc.setFillColor(...palette.primary);
      doc.rect(margin, y, contentWidth, 7, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(255, 255, 255);

      sec.table.headers.forEach((h, colIdx) => {
        doc.text(h, margin + colIdx * colWidth + 3, y + 5);
      });
      y += 7;

      // Table Rows
      sec.table.rows.forEach((row, rowIdx) => {
        checkPageBreak(8);
        const isEven = rowIdx % 2 === 0;
        doc.setFillColor(isEven ? 248 : 255, isEven ? 250 : 255, isEven ? 252 : 255);
        doc.rect(margin, y, contentWidth, 7, 'F');

        doc.setDrawColor(226, 232, 240);
        doc.line(margin, y + 7, margin + contentWidth, y + 7);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(51, 65, 85);

        row.forEach((cell, cellIdx) => {
          const truncated = doc.splitTextToSize(cell, colWidth - 4)[0] || '';
          doc.text(truncated, margin + cellIdx * colWidth + 3, y + 5);
        });
        y += 7;
      });
      y += 6;
    }

    y += 6;
  });

  // Footer for all pages
  const totalPages = doc.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(160, 160, 160);
    doc.text(
      `NexusAI Intelligence Studio • Document vérifié conforme • Page ${p} / ${totalPages}`,
      pageWidth / 2,
      pageHeight - 10,
      { align: 'center' }
    );
  }

  return doc;
}

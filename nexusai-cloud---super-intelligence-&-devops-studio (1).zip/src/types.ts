export type ActiveTab =
  | 'omni'
  | 'images'
  | 'pdf'
  | 'academic'
  | 'appforge'
  | 'cloud'
  | 'maintenance'
  | 'analytics'
  | 'feedback'
  | 'collab'
  | 'admin';

export interface GeneratedImage {
  id: string;
  prompt: string;
  enhancedPrompt?: string;
  style: string;
  aspectRatio: string;
  imageUrl: string;
  sourceType: 'diffusion' | 'procedural_vector';
  createdAt: string;
}

export interface GeneratedPdfSection {
  heading: string;
  content: string;
  bullets?: string[];
  callout?: string;
  table?: {
    headers: string[];
    rows: string[][];
  };
}

export interface GeneratedPdfDoc {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  author: string;
  date: string;
  abstract?: string;
  sections: GeneratedPdfSection[];
  themeColor?: 'blue' | 'emerald' | 'carbon' | 'purple';
}

export interface GeneratedApp {
  id: string;
  appName: string;
  summary: string;
  htmlContent: string;
  techStack: string[];
  deploymentManifest: string;
  featuresImplemented: string[];
  deployedUrl?: string;
  createdAt: string;
  status: 'draft' | 'building' | 'deployed';
}

export interface AcademicQuery {
  id: string;
  subject: string;
  level: string;
  problem: string;
  solution: string;
  timestamp: string;
  saved?: boolean;
}

export interface Incident {
  id: string;
  title: string;
  severity: 'P1 - Critique' | 'P2 - Majeur' | 'P3 - Mineur';
  service: string;
  region: string;
  status: 'Actif' | 'En cours d\'analyse' | 'Résolu' | 'Rollback effectué';
  logs: string;
  detectedAt: string;
  aiDiagnostic?: string;
  remediationScript?: string;
}

export interface UserFeedback {
  id: string;
  user: string;
  role: string;
  sentiment: 'positive' | 'neutral' | 'issue' | 'feature';
  message: string;
  rating: number;
  timestamp: string;
  status: 'Nouveau' | 'En cours' | 'Résolu';
  upvotes: number;
}

export interface GitCommit {
  hash: string;
  branch: string;
  author: string;
  message: string;
  timestamp: string;
  changes: { added: number; deleted: number };
}

export interface TelemetryData {
  rps: number;
  p95LatencyMs: number;
  errorRate: string;
  uptimePct: number;
  activeNodes: number;
  cpuPct: number;
  memoryMb: number;
  totalTokens: number;
  costEst: number;
}

export interface AdminSettings {
  aiModel: string;
  temperature: number;
  creativityMode: 'unbounded' | 'balanced' | 'strict';
  autoHealing: boolean;
  minReplicas: number;
  maxReplicas: number;
  themeAccent: 'cyan' | 'emerald' | 'violet' | 'amber';
  wafLevel: 'high' | 'paranoid' | 'standard';
  autoDeployProd: boolean;
}

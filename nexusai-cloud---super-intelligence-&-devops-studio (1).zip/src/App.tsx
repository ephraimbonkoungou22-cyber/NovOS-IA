import React, { useState, useEffect } from 'react';
import { ActiveTab, AdminSettings, Incident } from './types';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { OmniGenerator } from './components/OmniGenerator';
import { ImageStudio } from './components/ImageStudio';
import { PdfStudio } from './components/PdfStudio';
import { AcademicTutor } from './components/AcademicTutor';
import { AppForge } from './components/AppForge';
import { CloudArchitecture } from './components/CloudArchitecture';
import { AutoMaintenance } from './components/AutoMaintenance';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { LiveFeedback } from './components/LiveFeedback';
import { CollaborationHub } from './components/CollaborationHub';
import { AdminConsole } from './components/AdminConsole';
import { CommandPalette } from './components/CommandPalette';
import { Menu, X } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('omni');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [liveRps, setLiveRps] = useState(1942);

  const [adminSettings, setAdminSettings] = useState<AdminSettings>({
    aiModel: 'gemini-3.8-flash',
    temperature: 0.8,
    creativityMode: 'unbounded',
    autoHealing: true,
    minReplicas: 8,
    maxReplicas: 128,
    themeAccent: 'cyan',
    wafLevel: 'high',
    autoDeployProd: true,
  });

  const [incidents, setIncidents] = useState<Incident[]>([
    {
      id: 'INC-889',
      title: 'Pic de latence passager sur nœud Ingress (eu-west3)',
      severity: 'P2 - Majeur',
      service: 'Envoy Ingress Gateway',
      region: 'eu-west3 (Francfort)',
      status: 'Actif',
      logs: '2026-10-27T12:44:01Z [WARN] upstream response time exceeded threshold (1240ms > 50ms) on worker-pool-03\n2026-10-27T12:44:02Z [ERROR] connection pool exhausted, queuing 42 requests',
      detectedAt: 'Il y a 6 minutes',
    },
    {
      id: 'INC-888',
      title: 'Saturation temporaire du cache de session Redis',
      severity: 'P3 - Mineur',
      service: 'Redis Cluster Memory',
      region: 'us-east1 (Virginie)',
      status: 'Rollback effectué',
      logs: '2026-10-27T11:15:32Z [INFO] Memory eviction policy allkeys-lru triggered. Purged 12MB of stale keys.',
      detectedAt: 'Il y a 1h 20m',
      aiDiagnostic: 'Le cache Redis a atteint son seuil de sécurité de 85%. Le redimensionnement dynamique de la mémoire allouée a résolu l\'incident avec 0 perte de données.',
    },
  ]);

  // Live RPS fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveRps((prev) => {
        const delta = Math.floor(Math.random() * 50) - 25;
        return Math.max(1600, prev + delta);
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Global shortcut Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Theme accent background glow
  const getThemeGlow = () => {
    switch (adminSettings.themeAccent) {
      case 'emerald':
        return 'from-emerald-950/20 via-slate-950 to-slate-950';
      case 'violet':
        return 'from-purple-950/20 via-slate-950 to-slate-950';
      case 'amber':
        return 'from-amber-950/20 via-slate-950 to-slate-950';
      default:
        return 'from-cyan-950/20 via-slate-950 to-slate-950';
    }
  };

  return (
    <div className={`min-h-screen bg-gradient-to-b ${getThemeGlow()} text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-white`}>
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openCommandPalette={() => setIsCommandPaletteOpen(true)}
        adminSettings={adminSettings}
        setAdminSettings={setAdminSettings}
        liveRps={liveRps}
      />

      {/* Mobile Drawer Toggle */}
      <div className="md:hidden flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800 text-xs">
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 font-semibold"
        >
          {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>Menu Modules</span>
        </button>
        <span className="font-mono text-cyan-400 text-[11px] font-bold">
          {activeTab.toUpperCase()}
        </span>
      </div>

      {/* Main Layout Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar (Desktop) */}
        <div className="hidden md:flex">
          <Sidebar
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            adminSettings={adminSettings}
            incidentCount={incidents.filter((i) => i.status !== 'Rollback effectué' && i.status !== 'Résolu').length}
            feedbackCount={4}
          />
        </div>

        {/* Sidebar (Mobile Overlay) */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <div
              className="fixed inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative z-10 w-72 bg-slate-950 h-full border-r border-slate-800 flex flex-col shadow-2xl">
              <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                <span className="font-bold text-sm text-white">Modules NexusAI</span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                <Sidebar
                  activeTab={activeTab}
                  setActiveTab={(tab) => {
                    setActiveTab(tab);
                    setMobileMenuOpen(false);
                  }}
                  adminSettings={adminSettings}
                  incidentCount={incidents.filter((i) => i.status !== 'Rollback effectué').length}
                  feedbackCount={4}
                />
              </div>
            </div>
          </div>
        )}

        {/* Main Content Pane */}
        <main className="flex-1 overflow-y-auto relative">
          {activeTab === 'omni' && (
            <OmniGenerator
              adminSettings={adminSettings}
              onNavigateImages={() => setActiveTab('images')}
              onNavigatePdf={() => setActiveTab('pdf')}
            />
          )}
          {activeTab === 'images' && (
            <ImageStudio onExportToPdf={() => setActiveTab('pdf')} />
          )}
          {activeTab === 'pdf' && <PdfStudio />}
          {activeTab === 'academic' && <AcademicTutor />}
          {activeTab === 'appforge' && <AppForge />}
          {activeTab === 'cloud' && <CloudArchitecture />}
          {activeTab === 'maintenance' && <AutoMaintenance />}
          {activeTab === 'analytics' && <AnalyticsDashboard liveRps={liveRps} />}
          {activeTab === 'feedback' && <LiveFeedback />}
          {activeTab === 'collab' && (
            <CollaborationHub incidents={incidents} setIncidents={setIncidents} />
          )}
          {activeTab === 'admin' && (
            <AdminConsole settings={adminSettings} setSettings={setAdminSettings} />
          )}
        </main>
      </div>

      {/* Global Command Palette */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        setActiveTab={setActiveTab}
      />
    </div>
  );
}

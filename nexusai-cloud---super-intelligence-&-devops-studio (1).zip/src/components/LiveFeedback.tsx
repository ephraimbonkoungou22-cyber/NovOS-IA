import React, { useState } from 'react';
import { 
  MessageSquareHeart, 
  ThumbsUp, 
  AlertCircle, 
  Lightbulb, 
  CheckCircle2, 
  Send, 
  Filter, 
  Sparkles, 
  Star,
  Users,
  RefreshCw,
  MessageCircle
} from 'lucide-react';
import { UserFeedback } from '../types';

export const LiveFeedback: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'positive' | 'issue' | 'feature'>('all');
  const [newFeedbackMessage, setNewFeedbackMessage] = useState('');
  const [newFeedbackSentiment, setNewFeedbackSentiment] = useState<'positive' | 'issue' | 'feature'>('positive');
  const [respondingId, setRespondingId] = useState<string | null>(null);
  const [aiReplies, setAiReplies] = useState<{ [id: string]: string }>({});

  const [feedbacks, setFeedbacks] = useState<UserFeedback[]>([
    {
      id: 'fb-01',
      user: 'Dr. Lucas V.',
      role: 'Chercheur en Physique Quantique',
      sentiment: 'positive',
      message: 'Le tuteur académique en temps réel a résolu l\'équation de Dirac avec une rigueur analytique stupéfiante. C\'est un gain de temps inestimable pour mes étudiants de master.',
      rating: 5,
      timestamp: 'Il y a 4 min',
      status: 'Nouveau',
      upvotes: 24,
    },
    {
      id: 'fb-02',
      user: 'Sophie Moreau',
      role: 'Lead DevOps @ CloudScale',
      sentiment: 'feature',
      message: 'Le déploiement automatique sur Kubernetes fonctionne parfaitement. Serait-il possible d\'ajouter une option pour exporter directement en chart Helm ?',
      rating: 4,
      timestamp: 'Il y a 14 min',
      status: 'En cours',
      upvotes: 18,
    },
    {
      id: 'fb-03',
      user: 'Marc Dupont',
      role: 'Ingénieur Frontend',
      sentiment: 'issue',
      message: 'Léger délai de rafraîchissement sur le sandbox iframe lors de l\'import d\'une bibliothèque externe CDN sous Firefox. Sinon l\'éditeur de code est ultra fluide.',
      rating: 4,
      timestamp: 'Il y a 28 min',
      status: 'Nouveau',
      upvotes: 7,
    },
    {
      id: 'fb-04',
      user: 'Elena Rostova',
      role: 'Architecte Solutions Cloud',
      sentiment: 'positive',
      message: 'L\'architecture cloud à auto-scaling avec WAF Zero-Trust a tenu le pic de 120 000 requêtes/seconde sans la moindre hausse de latence. Incroyable réactivité.',
      rating: 5,
      timestamp: 'Il y a 45 min',
      status: 'Résolu',
      upvotes: 42,
    },
  ]);

  const handleUpvote = (id: string) => {
    setFeedbacks((prev) =>
      prev.map((fb) => (fb.id === id ? { ...fb, upvotes: fb.upvotes + 1 } : fb))
    );
  };

  const handleResolve = (id: string) => {
    setFeedbacks((prev) =>
      prev.map((fb) => (fb.id === id ? { ...fb, status: 'Résolu' } : fb))
    );
  };

  const handleGenerateAiResponse = async (fb: UserFeedback) => {
    setRespondingId(fb.id);
    try {
      const res = await fetch('/api/ai/omni-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Génère une réponse technique professionnelle, courtoise et immédiate au retour de l'utilisateur suivant :
Utilisateur : ${fb.user} (${fb.role})
Type : ${fb.sentiment}
Message : "${fb.message}"
Propose soit un remerciement avec détails techniques, soit un plan de résolution d'ingénierie immédiat.`,
          temperature: 0.5,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setAiReplies((prev) => ({ ...prev, [fb.id]: data.result }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setRespondingId(null);
    }
  };

  const handleAddFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFeedbackMessage.trim()) return;

    const newFb: UserFeedback = {
      id: `fb-${Date.now().toString(36)}`,
      user: 'Vous (Admin Session)',
      role: 'Ingénieur Système',
      sentiment: newFeedbackSentiment,
      message: newFeedbackMessage,
      rating: 5,
      timestamp: 'À l\'instant',
      status: 'Nouveau',
      upvotes: 1,
    };

    setFeedbacks([newFb, ...feedbacks]);
    setNewFeedbackMessage('');
  };

  const filteredFeedbacks = feedbacks.filter((fb) => {
    if (filter === 'all') return true;
    return fb.sentiment === filter;
  });

  return (
    <div className="h-full flex flex-col p-4 lg:p-6 max-w-7xl mx-auto w-full space-y-6 overflow-y-auto">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-rose-950/60 via-slate-900 to-indigo-950/50 border border-rose-500/20 p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30">
                <MessageSquareHeart className="w-4 h-4 text-rose-400" />
              </span>
              <span className="text-xs font-mono font-semibold tracking-wider uppercase text-rose-400">
                Voix des Utilisateurs & Triage Direct
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Retours Utilisateurs en Direct
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl mt-1 leading-relaxed">
              Flux continu des avis, suggestions de fonctionnalités et signalements de bogues avec analyse de sentiment IA et réponses automatisées.
            </p>
          </div>

          {/* NPS Score Card */}
          <div className="flex items-center gap-3 bg-slate-950/90 p-4 rounded-xl border border-rose-500/30 self-start md:self-auto">
            <div className="text-center">
              <div className="text-[10px] text-slate-400 uppercase font-mono font-semibold">Net Promoter Score</div>
              <div className="text-3xl font-black text-emerald-400 font-mono">+78</div>
              <div className="text-[10px] text-emerald-300 font-medium">Excellente Satisfaction</div>
            </div>
          </div>
        </div>
      </div>

      {/* New Feedback Submission Bar */}
      <form onSubmit={handleAddFeedback} className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-slate-200">
          <span className="flex items-center gap-1.5">
            <MessageCircle className="w-3.5 h-3.5 text-rose-400" />
            Simuler ou Publier un Retour Utilisateur en Direct :
          </span>
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-400">Type :</span>
            <select
              value={newFeedbackSentiment}
              onChange={(e) => setNewFeedbackSentiment(e.target.value as any)}
              className="bg-slate-950 text-slate-200 rounded px-2 py-0.5 border border-slate-800 focus:outline-none"
            >
              <option value="positive">Avis Positif</option>
              <option value="feature">Demande de Fonctionnalité</option>
              <option value="issue">Signalement Problème / Bug</option>
            </select>
          </div>
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            value={newFeedbackMessage}
            onChange={(e) => setNewFeedbackMessage(e.target.value)}
            placeholder="Exprimez une expérience utilisateur, suggestion ou constat sur le système..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-rose-500/50"
          />
          <button
            type="submit"
            disabled={!newFeedbackMessage.trim()}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-400 hover:to-pink-500 text-white font-bold text-xs shadow-md disabled:opacity-40 transition-all shrink-0"
          >
            Publier dans le Flux
          </button>
        </div>
      </form>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${filter === 'all' ? 'bg-rose-500 text-white font-bold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Tous ({feedbacks.length})
          </button>
          <button
            onClick={() => setFilter('positive')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${filter === 'positive' ? 'bg-rose-500 text-white font-bold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Positifs
          </button>
          <button
            onClick={() => setFilter('feature')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${filter === 'feature' ? 'bg-rose-500 text-white font-bold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Fonctionnalités
          </button>
          <button
            onClick={() => setFilter('issue')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${filter === 'issue' ? 'bg-rose-500 text-white font-bold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Incidents / Bugs
          </button>
        </div>

        <span className="text-xs text-slate-400 font-mono">
          {filteredFeedbacks.length} retours affichés
        </span>
      </div>

      {/* Feed List */}
      <div className="space-y-3">
        {filteredFeedbacks.map((fb) => (
          <div
            key={fb.id}
            className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all space-y-3"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 to-rose-600 flex items-center justify-center font-bold text-xs text-white">
                  {fb.user.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">{fb.user}</span>
                    <span className="text-[10px] text-slate-400">• {fb.role}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">{fb.timestamp}</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold uppercase border ${
                    fb.sentiment === 'positive'
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : fb.sentiment === 'feature'
                      ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                      : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                  }`}
                >
                  {fb.sentiment}
                </span>

                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-medium ${
                    fb.status === 'Résolu'
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {fb.status}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed pl-12">{fb.message}</p>

            {/* AI Generated Reply */}
            {aiReplies[fb.id] && (
              <div className="ml-12 p-3 rounded-xl bg-slate-950 border border-purple-500/40 space-y-1">
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-purple-300">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>Réponse IA Générée :</span>
                </div>
                <p className="text-xs text-slate-300 whitespace-pre-wrap">{aiReplies[fb.id]}</p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-between pl-12 pt-2 border-t border-slate-800/80 text-xs">
              <button
                onClick={() => handleUpvote(fb.id)}
                className="flex items-center gap-1.5 text-slate-400 hover:text-cyan-400 transition-colors"
              >
                <ThumbsUp className="w-3.5 h-3.5" />
                <span className="font-mono">{fb.upvotes}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleGenerateAiResponse(fb)}
                  disabled={respondingId === fb.id}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-300 text-xs font-medium transition-all"
                >
                  {respondingId === fb.id ? (
                    <RefreshCw className="w-3 h-3 animate-spin" />
                  ) : (
                    <Sparkles className="w-3 h-3" />
                  )}
                  <span>Générer Réponse IA</span>
                </button>

                {fb.status !== 'Résolu' && (
                  <button
                    onClick={() => handleResolve(fb.id)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-emerald-500/20 hover:text-emerald-400 hover:border-emerald-500/40 border border-slate-700 text-slate-300 text-xs transition-all"
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Marquer Résolu</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Wand2, 
  Copy, 
  Check, 
  Download, 
  Flame, 
  Terminal, 
  RefreshCw,
  Code2,
  Atom,
  Lightbulb,
  Rocket,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Image as ImageIcon,
  MessageSquare,
  Bot,
  User,
  Trash2,
  Upload,
  ArrowRight,
  FileText
} from 'lucide-react';
import { AdminSettings } from '../types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  tokens?: number;
}

interface OmniGeneratorProps {
  adminSettings: AdminSettings;
  onNavigateImages?: () => void;
  onNavigatePdf?: () => void;
}

export const OmniGenerator: React.FC<OmniGeneratorProps> = ({
  adminSettings,
  onNavigateImages,
  onNavigatePdf,
}) => {
  const [subMode, setSubMode] = useState<'chat' | 'vision' | 'studio'>('chat');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-init',
      role: 'assistant',
      content: "Bonjour ! Je suis Nexus AI, votre intelligence artificielle universelle débridée. Je suis prête à concevoir n'importe quel système, résoudre des théories complexes, coder des applications ou analyser des images sans aucune restriction de temps ni de sujet. Que souhaitez-vous créer aujourd'hui ?",
      timestamp: 'À l\'instant',
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(true);

  // Vision state
  const [visionImage, setVisionImage] = useState<string | null>(null);
  const [visionPrompt, setVisionPrompt] = useState('Analyse cette image en détail, extrais les équations ou le schéma et résous le problème.');
  const [visionLoading, setVisionLoading] = useState(false);
  const [visionResult, setVisionResult] = useState<string | null>(null);

  // Studio generator state
  const [studioPrompt, setStudioPrompt] = useState('');
  const [studioPreset, setStudioPreset] = useState('Ingénierie & Systèmes Complexes');
  const [temperature, setTemperature] = useState(adminSettings.temperature || 0.8);
  const [studioLoading, setStudioLoading] = useState(false);
  const [studioResult, setStudioResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Speech Synthesis
  const speakText = (text: string) => {
    if (!speechEnabled || typeof window === 'undefined' || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();

    // Clean markdown before speaking
    const clean = text.replace(/[#*`$\-_]/g, ' ').slice(0, 350);
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = 'fr-FR';
    utterance.rate = 1.05;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  // Speech Recognition (Microphone)
  const toggleListening = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("La reconnaissance vocale n'est pas supportée par ce navigateur.");
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'fr-FR';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputMessage((prev) => (prev ? prev + ' ' + transcript : transcript));
        setIsListening(false);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } catch (e) {
      setIsListening(false);
    }
  };

  // Send message in multi-turn chat
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isTyping) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsTyping(true);

    try {
      const history = [...messages, userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: history,
          temperature,
          systemInstruction:
            'Tu es Nexus AI, une intelligence artificielle universelle d\'élite, polymath, sans filtre ni bride. Réponds avec une clarté remarquable, de la vivacité intellectuelle, des exemples et du code complet si pertinent. Réponds en français.',
        }),
      });

      const data = await res.json();
      if (data.success && data.reply) {
        const assistantMsg: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: data.reply,
          timestamp: new Date().toLocaleTimeString(),
        };
        setMessages((prev) => [...prev, assistantMsg]);
        speakText(data.reply);
      } else {
        const errorMsg: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: `Erreur : ${data.error || 'Impossible d\'obtenir une réponse.'}`,
          timestamp: new Date().toLocaleTimeString(),
        };
        setMessages((prev) => [...prev, errorMsg]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: `Erreur de connexion : ${err.message}`,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  // Vision image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setVisionImage(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Run multimodal vision solve
  const handleVisionSolve = async () => {
    if (!visionImage) return;
    setVisionLoading(true);
    setVisionResult(null);

    try {
      const res = await fetch('/api/ai/vision-solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: visionImage,
          prompt: visionPrompt,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setVisionResult(data.analysis);
        speakText(data.analysis);
      } else {
        setVisionResult(`Erreur : ${data.error}`);
      }
    } catch (err: any) {
      setVisionResult(`Erreur réseau : ${err.message}`);
    } finally {
      setVisionLoading(false);
    }
  };

  // Studio unbounded generator
  const handleStudioGenerate = async () => {
    if (!studioPrompt.trim()) return;
    setStudioLoading(true);
    setStudioResult(null);

    try {
      const res = await fetch('/api/ai/omni-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: studioPrompt,
          preset: studioPreset,
          temperature,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setStudioResult(data.result);
      } else {
        setStudioResult(`Erreur : ${data.error}`);
      }
    } catch (err: any) {
      setStudioResult(`Erreur : ${err.message}`);
    } finally {
      setStudioLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col p-4 lg:p-6 max-w-7xl mx-auto w-full space-y-4 overflow-y-auto">
      {/* Top Selector Modes */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-gradient-to-r from-purple-950/70 via-slate-900 to-indigo-950/60 border border-purple-500/20 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
            <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold text-white">IA Universelle Débridée</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/20 text-purple-300 border border-purple-500/30">
                TEMPS RÉEL • MULTIMODAL
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Dialogue interactif en direct, analyse visuelle de documents et génération de systèmes sans limite.
            </p>
          </div>
        </div>

        {/* Submode Switcher Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setSubMode('chat')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
              subMode === 'chat'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat Interactif & Voix</span>
          </button>

          <button
            onClick={() => setSubMode('vision')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
              subMode === 'vision'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Vision & Analyse Document</span>
          </button>

          <button
            onClick={() => setSubMode('studio')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
              subMode === 'studio'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Rocket className="w-3.5 h-3.5" />
            <span>Studio Grandes Synthèses</span>
          </button>
        </div>
      </div>

      {/* MODE 1: REAL-TIME CONVERSATIONAL CHAT & VOICE */}
      {subMode === 'chat' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col h-[650px] overflow-hidden">
          {/* Chat Header */}
          <div className="flex items-center justify-between px-5 py-3 bg-slate-950 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="text-xs font-bold text-slate-200">Conversation Directe avec l'IA</span>
              <span className="text-[10px] text-slate-500 font-mono">Modèle Gemini 3.8 Flash</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (isSpeaking) stopSpeaking();
                  else setSpeechEnabled(!speechEnabled);
                }}
                className={`p-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition-all ${
                  speechEnabled
                    ? 'bg-purple-500/10 text-purple-300 border-purple-500/40'
                    : 'bg-slate-900 text-slate-500 border-slate-800'
                }`}
                title={speechEnabled ? 'Voix IA Active' : 'Voix Désactivée'}
              >
                {speechEnabled ? <Volume2 className="w-4 h-4 text-purple-400" /> : <VolumeX className="w-4 h-4" />}
                <span className="text-[11px] hidden sm:inline">{isSpeaking ? 'En train de parler...' : speechEnabled ? 'Voix On' : 'Muet'}</span>
              </button>

              <button
                onClick={() => setMessages([messages[0]])}
                className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-rose-400 border border-slate-800 transition-colors"
                title="Effacer l'historique"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${
                  msg.role === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {msg.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center shrink-0 shadow">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed shadow-md ${
                    msg.role === 'user'
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-br-none'
                      : 'bg-slate-950 border border-slate-800/80 text-slate-200 rounded-bl-none'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.content}</div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 pt-2 border-t border-white/10 font-mono">
                    <span>{msg.timestamp}</span>
                    {msg.role === 'assistant' && (
                      <div className="flex items-center gap-2.5">
                        {onNavigateImages && (
                          <button
                            onClick={onNavigateImages}
                            className="flex items-center gap-1 text-[10px] text-purple-400 hover:text-purple-300 px-1.5 py-0.5 rounded bg-purple-950/40 border border-purple-800/40 transition-colors"
                            title="Créer une image sur ce sujet"
                          >
                            <ImageIcon className="w-3 h-3" />
                            <span className="hidden sm:inline">Créer Image</span>
                          </button>
                        )}
                        {onNavigatePdf && (
                          <button
                            onClick={onNavigatePdf}
                            className="flex items-center gap-1 text-[10px] text-emerald-400 hover:text-emerald-300 px-1.5 py-0.5 rounded bg-emerald-950/40 border border-emerald-800/40 transition-colors"
                            title="Compiler en PDF structuré"
                          >
                            <FileText className="w-3 h-3" />
                            <span className="hidden sm:inline">Exporter PDF</span>
                          </button>
                        )}
                        <button
                          onClick={() => speakText(msg.content)}
                          className="hover:text-purple-300 transition-colors"
                          title="Écouter la voix"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleCopy(msg.content)}
                          className="hover:text-cyan-300 transition-colors"
                          title="Copier le texte"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {msg.role === 'user' && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0">
                    <User className="w-4 h-4 text-slate-300" />
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-purple-600 flex items-center justify-center shrink-0 animate-pulse">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-purple-300 flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-purple-400" />
                  <span>L'IA analyse et formule sa réponse en temps réel...</span>
                </div>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Prompt Suggestions Bar */}
          <div className="px-4 py-2 bg-slate-950/60 border-t border-slate-800 flex items-center gap-2 overflow-x-auto text-[11px]">
            <span className="text-slate-500 font-mono shrink-0">Questions rapides :</span>
            {[
              "Explique le principe d'équivalence d'Einstein simplement",
              "Conçois un smart contract avec consensus rapide",
              "Comment optimiser une requête SQL sur 10M de lignes ?",
              "Crée une histoire de science-fiction cyberpunk",
            ].map((sugg, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(sugg)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 shrink-0 transition-colors"
              >
                {sugg}
              </button>
            ))}
          </div>

          {/* Chat Input Bar */}
          <div className="p-3.5 bg-slate-950 border-t border-slate-800">
            <div className="flex items-center gap-2">
              {/* Mic button */}
              <button
                onClick={toggleListening}
                className={`p-2.5 rounded-xl border transition-all ${
                  isListening
                    ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
                    : 'bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-purple-300 border-slate-800'
                }`}
                title={isListening ? 'Arrêter le micro' : 'Parler au micro'}
              >
                {isListening ? <Mic className="w-4 h-4 animate-bounce" /> : <Mic className="w-4 h-4" />}
              </button>

              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder={isListening ? "Écoute en cours... Parlez maintenant !" : "Posez une question, donnez un défi logique ou demandez une création sans limite..."}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              />

              <button
                onClick={() => handleSendMessage()}
                disabled={isTyping || !inputMessage.trim()}
                className="p-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md disabled:opacity-40 transition-all"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODE 2: MULTIMODAL VISION & DOCUMENT SOLVER */}
      {subMode === 'vision' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upload & Preview */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-purple-400" />
              <span>Charger un Document, Exercice ou Schéma</span>
            </h2>

            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-800 hover:border-purple-500/60 rounded-xl p-8 text-center cursor-pointer transition-all bg-slate-950/60 group flex flex-col items-center justify-center min-h-[220px]"
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageUpload}
                accept="image/*"
                className="hidden"
              />

              {visionImage ? (
                <div className="relative group max-h-60 overflow-hidden rounded-lg">
                  <img src={visionImage} alt="Uploaded" className="max-h-56 object-contain rounded-lg" />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs font-semibold transition-opacity">
                    Cliquer pour changer d'image
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="w-12 h-12 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div className="text-xs font-semibold text-slate-200">
                    Glissez-déposez ou cliquez pour uploader une image
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Photo de tableau noir, exercice manuscrit, capture d'écran d'erreur ou schéma d'architecture
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-300">Consigne d'analyse :</label>
              <input
                type="text"
                value={visionPrompt}
                onChange={(e) => setVisionPrompt(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-500"
              />
            </div>

            <button
              onClick={handleVisionSolve}
              disabled={visionLoading || !visionImage}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white font-bold text-xs shadow-md disabled:opacity-40 transition-all flex items-center justify-center gap-2"
            >
              {visionLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Analyse Multimodale en cours...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Lancer l'Analyse Visuelle Complète</span>
                </>
              )}
            </button>
          </div>

          {/* Vision Result */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-xl flex flex-col">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-200">Rapport d'Analyse Multimodale</span>
              {visionResult && (
                <button
                  onClick={() => handleCopy(visionResult)}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copié !' : 'Copier'}</span>
                </button>
              )}
            </div>

            <div className="flex-1 bg-slate-950 rounded-xl p-4 border border-slate-800/80 text-xs text-slate-200 overflow-y-auto leading-relaxed whitespace-pre-wrap font-sans">
              {visionResult ? (
                visionResult
              ) : (
                <div className="text-center py-16 text-slate-500 space-y-2">
                  <ImageIcon className="w-8 h-8 mx-auto text-slate-600" />
                  <div>Chargez une image pour que l'IA en extraie les données et résolve la problématique.</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODE 3: STUDIO GRANDES SYNTHÈSES SANS RESTRICTIONS */}
      {subMode === 'studio' && (
        <div className="space-y-4">
          {/* Preset buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {[
              { name: 'Ingénierie & Systèmes Complexes', icon: Rocket },
              { name: 'Sciences Avancées & R&D', icon: Atom },
              { name: 'Création & Fiction Débridée', icon: Flame },
              { name: 'Algorithmique & Mathématiques', icon: Code2 },
            ].map((p) => {
              const Icon = p.icon;
              const active = studioPreset === p.name;
              return (
                <button
                  key={p.name}
                  onClick={() => setStudioPreset(p.name)}
                  className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
                    active
                      ? 'bg-purple-950/60 border-purple-500 text-purple-300 font-bold'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4" />
                    <span className="text-xs">{p.name}</span>
                  </div>
                  {active && <span className="w-2 h-2 rounded-full bg-purple-400"></span>}
                </button>
              );
            })}
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
            <textarea
              value={studioPrompt}
              onChange={(e) => setStudioPrompt(e.target.value)}
              placeholder="Exprimez librement votre vision, équation, concept ou architecture sans limitation..."
              rows={4}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500 resize-none font-sans"
            />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>Créativité (Temp) :</span>
                <input
                  type="range"
                  min="0.1"
                  max="1.5"
                  step="0.05"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-20 accent-purple-500"
                />
                <span className="font-mono text-purple-300">{temperature}</span>
              </div>

              <button
                onClick={handleStudioGenerate}
                disabled={studioLoading || !studioPrompt.trim()}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-md disabled:opacity-40 transition-all flex items-center gap-2"
              >
                {studioLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span>Lancer la Synthèse Débridée</span>
              </button>
            </div>
          </div>

          {studioResult && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
                <span className="font-bold text-purple-300">Résultat de la Synthèse Omnisciente</span>
                <button
                  onClick={() => handleCopy(studioResult)}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copié !' : 'Copier'}</span>
                </button>
              </div>
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800/80 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                {studioResult}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

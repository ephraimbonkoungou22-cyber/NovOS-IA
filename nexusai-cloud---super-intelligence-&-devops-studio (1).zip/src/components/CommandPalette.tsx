import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Sparkles, 
  GraduationCap, 
  Layout, 
  Cloud, 
  Wrench, 
  BarChart3, 
  MessageSquareHeart, 
  GitBranch, 
  Sliders,
  X,
  ArrowRight,
  Image as ImageIcon,
  FileText
} from 'lucide-react';
import { ActiveTab } from '../types';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  setActiveTab: (tab: ActiveTab) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  setActiveTab,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const actions = [
    { id: 'omni' as ActiveTab, label: 'Assistant IA Universel & Chat', desc: 'Questions réelles, raisonnement approfondi & création', icon: Sparkles, color: 'text-cyan-400' },
    { id: 'images' as ActiveTab, label: 'Studio Images IA (Flux & Canvas 4K)', desc: 'Génération visuelle par diffusion et synthèse vectorielle', icon: ImageIcon, color: 'text-purple-400' },
    { id: 'pdf' as ActiveTab, label: 'Générateur & Exportateur de PDF', desc: 'Création de cours, rapports techniques et fiches en PDF A4', icon: FileText, color: 'text-emerald-400' },
    { id: 'academic' as ActiveTab, label: 'Tuteur Académique Temps Réel', desc: 'Résolution mathématiques supérieures, physique, chimie', icon: GraduationCap, color: 'text-indigo-400' },
    { id: 'appforge' as ActiveTab, label: 'Studio Web & Applications', desc: 'Générateur de code interactif et déploiement automatique', icon: Layout, color: 'text-cyan-400' },
    { id: 'cloud' as ActiveTab, label: 'Architecture Cloud & Autoscaling', desc: 'Topologie multi-région, pods Kubernetes et WAF Zero-Trust', icon: Cloud, color: 'text-blue-400' },
    { id: 'maintenance' as ActiveTab, label: 'Auto-Maintenance & Self-Healing', desc: 'Optimisation permanente des performances et fuites mémoire', icon: Wrench, color: 'text-emerald-400' },
    { id: 'analytics' as ActiveTab, label: 'Tableau de Bord Analytique & Télémétrie', desc: 'Débit en direct, latence p99, métriques de santé', icon: BarChart3, color: 'text-cyan-300' },
    { id: 'feedback' as ActiveTab, label: 'Retours Utilisateurs en Direct', desc: 'Flux d\'avis, NPS et réponses IA instantanées', icon: MessageSquareHeart, color: 'text-rose-400' },
    { id: 'collab' as ActiveTab, label: 'Gestion des Versions Git & War Room', desc: 'Branches Git, commits et résolution d\'incidents SRE', icon: GitBranch, color: 'text-indigo-300' },
    { id: 'admin' as ActiveTab, label: 'Console Administrateur Personnalisable', desc: 'Quotas, paramètres IA, WAF et liste blanche IP', icon: Sliders, color: 'text-slate-300' },
  ];

  const filtered = actions.filter((act) =>
    act.label.toLowerCase().includes(query.toLowerCase()) ||
    act.desc.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/70 backdrop-blur-md animate-fade-in">
      <div
        className="w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-800 bg-slate-900/80">
          <Search className="w-5 h-5 text-cyan-400" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tapez une commande ou le nom d'un module..."
            className="flex-1 bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none font-sans"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-2 max-h-96 overflow-y-auto space-y-1">
          {filtered.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  onClose();
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-900 text-left transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-slate-900 group-hover:bg-slate-850 border border-slate-800">
                    <Icon className={`w-4 h-4 ${item.color}`} />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300">
                      {item.label}
                    </div>
                    <div className="text-[11px] text-slate-400">{item.desc}</div>
                  </div>
                </div>

                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
              </button>
            );
          })}

          {filtered.length === 0 && (
            <div className="py-8 text-center text-xs text-slate-500">
              Aucun module ou commande ne correspond à votre recherche.
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2 bg-slate-900/90 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 font-mono">
          <span>Naviguer avec les flèches ou cliquer</span>
          <span>Échap pour fermer</span>
        </div>
      </div>
    </div>
  );
};

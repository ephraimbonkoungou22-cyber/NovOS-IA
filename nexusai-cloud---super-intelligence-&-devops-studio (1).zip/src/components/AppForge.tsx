import React, { useState, useEffect } from 'react';
import { 
  Layout, 
  Code, 
  Play, 
  Rocket, 
  Cloud, 
  CheckCircle2, 
  AlertCircle, 
  Copy, 
  Check, 
  Download, 
  RefreshCw, 
  ExternalLink, 
  Layers, 
  Terminal, 
  Sparkles,
  Smartphone,
  Monitor,
  Eye
} from 'lucide-react';
import { GeneratedApp } from '../types';

export const AppForge: React.FC = () => {
  const [prompt, setPrompt] = useState('Tableau de bord SaaS moderne avec cartes statistiques dynamiques, mode sombre et filtrage de données');
  const [framework, setFramework] = useState('HTML5 / TailwindCSS / Vanilla JS');
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'code' | 'deploy'>('preview');
  const [deviceView, setDeviceView] = useState<'desktop' | 'mobile'>('desktop');
  const [copied, setCopied] = useState(false);
  const [deployStep, setDeployStep] = useState<number>(0);
  const [isDeploying, setIsDeploying] = useState<boolean>(false);
  const [deployLogs, setDeployLogs] = useState<string[]>([]);
  const [modifyPrompt, setModifyPrompt] = useState<string>('');
  const [isModifying, setIsModifying] = useState<boolean>(false);

  const handleModifyCode = async (customInstruction?: string) => {
    const instruction = customInstruction || modifyPrompt;
    if (!instruction.trim() || isModifying) return;
    setIsModifying(true);
    try {
      const res = await fetch('/api/ai/code-modify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentHtml: currentApp.htmlContent,
          userPrompt: instruction,
        }),
      });
      const data = await res.json();
      if (data.success && data.updatedHtml) {
        setCurrentApp((prev) => ({
          ...prev,
          htmlContent: data.updatedHtml,
          featuresImplemented: [...prev.featuresImplemented, instruction],
        }));
        setModifyPrompt('');
      }
    } catch (err: any) {
      alert(`Erreur : ${err.message}`);
    } finally {
      setIsModifying(false);
    }
  };

  // Default app for instant user interaction
  const [currentApp, setCurrentApp] = useState<GeneratedApp>({
    id: 'app-alpha-101',
    appName: 'Nexus Quantum Analytics SaaS',
    summary: 'Dashboard SaaS interactif temps réel avec KPIs financiers, graphiques dynamiques et gestion de flux.',
    techStack: ['TailwindCSS CDN', 'ES6 JavaScript', 'HTML5 Canvas'],
    featuresImplemented: ['Calcul en direct des conversions', 'Graphique de trafic interactif', 'Mode Sombre Cyber'],
    createdAt: new Date().toLocaleDateString(),
    status: 'deployed',
    deployedUrl: 'https://app-quantum-analytics.nexus.cloud',
    deploymentManifest: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: nexus-quantum-analytics
  namespace: production
  labels:
    app: quantum-analytics
spec:
  replicas: 4
  selector:
    matchLabels:
      app: quantum-analytics
  template:
    metadata:
      labels:
        app: quantum-analytics
    spec:
      containers:
      - name: web
        image: gcr.io/nexus-cloud/quantum-analytics:v1.4.2
        ports:
        - containerPort: 80
        resources:
          limits:
            cpu: "500m"
            memory: "512Mi"`,
    htmlContent: `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quantum Analytics SaaS</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @keyframes pulse-slow { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
    .animate-pulse-slow { animation: pulse-slow 3s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen font-sans p-4 sm:p-6">
  <div class="max-w-6xl mx-auto space-y-6">
    <!-- Header -->
    <header class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
      <div>
        <div class="flex items-center gap-2">
          <span class="w-3 h-3 rounded-full bg-cyan-400 animate-ping"></span>
          <h1 class="text-xl sm:text-2xl font-black bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
            Quantum Analytics
          </h1>
          <span class="px-2 py-0.5 rounded text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">PROD</span>
        </div>
        <p class="text-xs text-slate-400 mt-1">Plateforme de métriques et télémétrie en direct</p>
      </div>

      <div class="flex items-center gap-3">
        <button id="refresh-btn" class="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 transition-all flex items-center gap-1.5">
          <span>Actualiser les flux</span>
        </button>
        <button class="px-4 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-xs font-bold text-white shadow-lg shadow-cyan-500/20">
          + Exporter CSV
        </button>
      </div>
    </header>

    <!-- Top KPI Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 hover:border-cyan-500/30 transition-all">
        <div class="text-xs text-slate-400 font-medium">Volume de Transactions</div>
        <div class="text-2xl font-extrabold text-white mt-1" id="kpi-volume">€248,920</div>
        <div class="text-xs text-emerald-400 mt-1 font-semibold flex items-center gap-1">
          ↑ +18.4% ce mois-ci
        </div>
      </div>

      <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 hover:border-cyan-500/30 transition-all">
        <div class="text-xs text-slate-400 font-medium">Utilisateurs Actifs</div>
        <div class="text-2xl font-extrabold text-cyan-400 mt-1" id="kpi-users">14,892</div>
        <div class="text-xs text-cyan-300 mt-1 font-semibold">
          ⚡ 940 connectés maintenant
        </div>
      </div>

      <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 hover:border-cyan-500/30 transition-all">
        <div class="text-xs text-slate-400 font-medium">Taux de Rétention</div>
        <div class="text-2xl font-extrabold text-purple-400 mt-1">94.8%</div>
        <div class="text-xs text-emerald-400 mt-1 font-semibold">
          ↑ +2.1% cohort Q4
        </div>
      </div>

      <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 hover:border-cyan-500/30 transition-all">
        <div class="text-xs text-slate-400 font-medium">Latence Globale</div>
        <div class="text-2xl font-extrabold text-emerald-400 mt-1">14.2 ms</div>
        <div class="text-xs text-slate-400 mt-1 font-mono">
          Edge CDN Anycast
        </div>
      </div>
    </div>

    <!-- Main Chart & Live Stream -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div class="lg:col-span-2 p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <div class="flex items-center justify-between">
          <h2 class="text-sm font-bold text-white flex items-center gap-2">
            <span>Graphique de Télémétrie en Direct</span>
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          </h2>
          <div class="flex items-center gap-1.5 text-xs text-slate-400">
            <span class="px-2 py-0.5 rounded bg-slate-800 text-slate-300">Temps Réel (1s)</span>
          </div>
        </div>

        <!-- Simulated Bar Chart -->
        <div class="h-48 flex items-end gap-2 pt-4 px-2 border-b border-slate-800/80" id="chart-bars">
          <!-- Populated by JS -->
        </div>

        <div class="flex items-center justify-between text-[11px] text-slate-500 font-mono">
          <span>00:00</span>
          <span>06:00</span>
          <span>12:00</span>
          <span>18:00</span>
          <span>En direct</span>
        </div>
      </div>

      <!-- Feed list -->
      <div class="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <h2 class="text-sm font-bold text-white">Événements Réseau</h2>
        <div class="space-y-2.5 text-xs" id="events-list">
          <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between">
            <div class="truncate">
              <div class="font-semibold text-slate-200">Session Checkout Confirmée</div>
              <div class="text-[10px] text-slate-400">Région : eu-west3 • 120ms</div>
            </div>
            <span class="text-emerald-400 font-mono font-bold">+€840</span>
          </div>
          <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between">
            <div class="truncate">
              <div class="font-semibold text-slate-200">Rebalance Pod Kubernetes</div>
              <div class="text-[10px] text-slate-400">Node-04 • CPU 32%</div>
            </div>
            <span class="text-cyan-400 font-mono">OK</span>
          </div>
          <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between">
            <div class="truncate">
              <div class="font-semibold text-slate-200">Synchronisation Cache Redis</div>
              <div class="text-[10px] text-slate-400">Hit-rate: 99.4%</div>
            </div>
            <span class="text-purple-400 font-mono font-bold">SY</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Live Bar generation
    const chart = document.getElementById('chart-bars');
    const heights = [45, 60, 50, 75, 90, 65, 80, 95, 110, 85, 120, 140, 130, 155, 145, 160];
    
    function renderChart() {
      chart.innerHTML = '';
      heights.forEach((h, i) => {
        const bar = document.createElement('div');
        bar.className = 'flex-1 bg-gradient-to-t from-cyan-600 to-indigo-500 rounded-t hover:opacity-80 transition-all';
        bar.style.height = h + 'px';
        bar.title = 'Index ' + i + ' : ' + (h * 42) + ' req';
        chart.appendChild(bar);
      });
    }
    renderChart();

    // Live counter updates
    let users = 14892;
    setInterval(() => {
      users += Math.floor(Math.random() * 5) - 2;
      document.getElementById('kpi-users').textContent = users.toLocaleString();
      // Shift chart slightly
      heights.shift();
      heights.push(Math.floor(70 + Math.random() * 90));
      renderChart();
    }, 2500);

    document.getElementById('refresh-btn').addEventListener('click', () => {
      renderChart();
    });
  </script>
</body>
</html>`,
  });

  const appTemplates = [
    { title: 'Dashboard SaaS Analytics', desc: 'KPIs en temps réel, graphiques et métriques', prompt: 'Crée un dashboard SaaS analytique ultra complet avec métriques temps réel, cartes statistiques animées et filtres' },
    { title: 'Store E-Commerce & Panier', desc: 'Catalogue produits, filtres, panier interactif', prompt: 'Crée une boutique e-commerce moderne de vêtements streetwear avec filtres de catégories, panier dynamique et checkout fluide' },
    { title: 'Plateforme Médicale & Télémédecine', desc: 'Prise de RDV, fiches patients et diagnostics', prompt: 'Crée une application de télémédecine avec recherche de médecins, calendrier de réservation interactif et messagerie chiffrée' },
    { title: 'Studio Audio & Synthétiseur Web', desc: 'Clavier virtuel, pads interactifs et fréquences', prompt: 'Crée un synthétiseur musical interactif avec Web Audio API, clavier tactile, pads rythmiques et visualiseur d\'ondes' },
  ];

  const handleCreateApp = async (customPrompt?: string) => {
    const textToSubmit = customPrompt || prompt;
    if (!textToSubmit.trim()) return;

    setLoading(true);
    try {
      const res = await fetch('/api/ai/code-forge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appDescription: textToSubmit,
          framework,
          features: ['Interface intuitive et moderne', 'Mode sombre élégant', 'Interactivité complète en JavaScript', 'Composants modulaires'],
        }),
      });

      const json = await res.json();
      if (json.success && json.data) {
        const appData = json.data;
        const newApp: GeneratedApp = {
          id: `app-${Date.now().toString(36)}`,
          appName: appData.appName || 'Application Web',
          summary: appData.summary || 'Application web générée par NexusAI',
          htmlContent: appData.htmlContent || '<div>App prête</div>',
          techStack: appData.techStack || ['HTML5', 'TailwindCSS', 'JavaScript'],
          deploymentManifest: appData.deploymentManifest || '# Cloud Run manifest',
          featuresImplemented: appData.featuresImplemented || ['Interface intuitive'],
          createdAt: new Date().toLocaleDateString(),
          status: 'draft',
        };
        setCurrentApp(newApp);
        setActiveTab('preview');
      } else {
        alert(json.error || 'Erreur lors de la création');
      }
    } catch (err: any) {
      alert(`Erreur de connexion : ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleStartDeploy = () => {
    if (isDeploying) return;
    setIsDeploying(true);
    setDeployStep(1);
    setDeployLogs([
      `[INIT] Déclenchement du pipeline CI/CD automatisé pour "${currentApp.appName}"...`,
    ]);

    const steps = [
      { step: 2, log: '[STAGE 1/5] Audit statique & vérification de sécurité WAF... PASS (0 vulnérabilité)' },
      { step: 3, log: '[STAGE 2/5] Build de l\'image de conteneur OCI & compression Brotli... PASS' },
      { step: 4, log: '[STAGE 3/5] Déploiement multi-région Kubernetes (eu-west3, us-east1, asia-east1)... PASS' },
      { step: 5, log: '[STAGE 4/5] Enregistrement DNS Anycast & Certificat TLS 1.3 Let\'s Encrypt... PASS' },
      { step: 6, log: `[STAGE 5/5] Déploiement terminé avec succès ! URL active : https://${currentApp.id}.edge.nexuscloud.io` },
    ];

    steps.forEach((s, index) => {
      setTimeout(() => {
        setDeployStep(s.step);
        setDeployLogs((prev) => [...prev, s.log]);
        if (index === steps.length - 1) {
          setIsDeploying(false);
          setCurrentApp((prev) => ({
            ...prev,
            status: 'deployed',
            deployedUrl: `https://${currentApp.id}.edge.nexuscloud.io`,
          }));
        }
      }, (index + 1) * 800);
    });
  };

  const handleDownloadZip = () => {
    const element = document.createElement('a');
    const file = new Blob([currentApp.htmlContent], { type: 'text/html' });
    element.href = URL.createObjectURL(file);
    element.download = `${currentApp.id}-index.html`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentApp.htmlContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col p-4 lg:p-6 max-w-7xl mx-auto w-full space-y-5 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-slate-900 to-blue-950/60 border border-cyan-500/20 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              <Layout className="w-4 h-4 text-cyan-400" />
            </span>
            <span className="text-xs font-mono font-semibold tracking-wider uppercase text-cyan-400">
              Web & App Forge • Déploiement Continu
            </span>
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Générateur d'Applications & Pipeline Cloud Automatisé
          </h1>
          <p className="text-slate-300 text-sm max-w-2xl mt-1 leading-relaxed">
            Créez n'importe quel site ou application interactive avec prévisualisation immédiate en temps réel, éditeur de code et déploiement 1-clic sur cluster cloud mondial.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleStartDeploy}
            disabled={isDeploying}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 disabled:opacity-50 transition-all transform active:scale-95"
          >
            {isDeploying ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>Déploiement en cours...</span>
              </>
            ) : (
              <>
                <Rocket className="w-4 h-4 text-white" />
                <span>Déployer sur le Cloud Auto</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Templates Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
        {appTemplates.map((tpl, i) => (
          <button
            key={i}
            onClick={() => {
              setPrompt(tpl.prompt);
              handleCreateApp(tpl.prompt);
            }}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 hover:border-cyan-500/40 text-left transition-all group"
          >
            <div className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300">
              {tpl.title}
            </div>
            <div className="text-[11px] text-slate-400 mt-1 line-clamp-1">{tpl.desc}</div>
          </button>
        ))}
      </div>

      {/* Prompt Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleCreateApp()}
            placeholder="Décrivez l'application ou le site web que vous souhaitez générer..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500"
          />
          <button
            onClick={() => handleCreateApp()}
            disabled={loading || !prompt.trim()}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-xs shadow-md shadow-cyan-600/20 disabled:opacity-40 transition-all shrink-0"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Génération Code...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Générer l'Application</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Workspace: Tabs & Viewer */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col min-h-[520px]">
        {/* Workspace Toolbar */}
        <div className="flex flex-wrap items-center justify-between px-4 py-2.5 bg-slate-950 border-b border-slate-800 gap-2">
          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-medium">
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'preview'
                  ? 'bg-cyan-500 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Aperçu Direct</span>
            </button>
            <button
              onClick={() => setActiveTab('code')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'code'
                  ? 'bg-cyan-500 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>Code Source HTML/JS</span>
            </button>
            <button
              onClick={() => setActiveTab('deploy')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'deploy'
                  ? 'bg-cyan-500 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Cloud className="w-3.5 h-3.5" />
              <span>Pipeline & Déploiement K8s</span>
            </button>
          </div>

          {/* Device toggle (for preview) & Actions */}
          <div className="flex items-center gap-2">
            {activeTab === 'preview' && (
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                <button
                  onClick={() => setDeviceView('desktop')}
                  className={`p-1 rounded ${deviceView === 'desktop' ? 'bg-slate-800 text-cyan-400' : 'text-slate-500 hover:text-slate-300'}`}
                  title="Vue Bureau"
                >
                  <Monitor className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setDeviceView('mobile')}
                  className={`p-1 rounded ${deviceView === 'mobile' ? 'bg-slate-800 text-cyan-400' : 'text-slate-500 hover:text-slate-300'}`}
                  title="Vue Mobile"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors text-xs"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copié !' : 'Copier'}</span>
            </button>

            <button
              onClick={handleDownloadZip}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors text-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Télécharger</span>
            </button>

            {currentApp.deployedUrl && (
              <a
                href={currentApp.deployedUrl}
                target="_blank"
                rel="noreferrer"
                className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-mono"
              >
                <ExternalLink className="w-3 h-3" />
                <span>Live URL</span>
              </a>
            )}
          </div>
        </div>

        {/* Tab Content 1: Live Preview Iframe */}
        {activeTab === 'preview' && (
          <div className="flex-1 flex flex-col bg-slate-950 p-2 sm:p-4 overflow-auto min-h-[500px]">
            <div className="flex-1 flex items-center justify-center">
              <div
                className={`transition-all duration-300 shadow-2xl rounded-xl overflow-hidden border border-slate-800 bg-white ${
                  deviceView === 'mobile'
                    ? 'w-[375px] h-[667px] ring-8 ring-slate-800'
                    : 'w-full h-[520px]'
                }`}
              >
                <iframe
                  title="Preview"
                  srcDoc={currentApp.htmlContent}
                  sandbox="allow-scripts allow-forms allow-same-origin allow-modals"
                  className="w-full h-full border-0"
                />
              </div>
            </div>

            {/* Interactive Code Modifier Bar */}
            <div className="mt-4 p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Modifier cette application en direct avec l'IA :</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  Mise à jour instantanée du code & du rendu
                </span>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={modifyPrompt}
                  onChange={(e) => setModifyPrompt(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleModifyCode()}
                  placeholder="Ex : 'Ajoute un bouton de téléchargement', 'Passe en thème néon violet', 'Ajoute un graphique supplémentaire'..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
                <button
                  onClick={() => handleModifyCode()}
                  disabled={isModifying || !modifyPrompt.trim()}
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-semibold text-xs shadow-md disabled:opacity-40 transition-all flex items-center gap-1.5 shrink-0"
                >
                  {isModifying ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Modification...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Appliquer Modification</span>
                    </>
                  )}
                </button>
              </div>

              {/* Quick preset modifications */}
              <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] pt-1">
                <span className="text-slate-500 font-mono shrink-0">Idées rapides :</span>
                {[
                  "Ajoute un mode clair/sombre interactif",
                  "Ajoute des animations au survol des cartes",
                  "Ajoute un panier d'achats avec total calculé",
                  "Intègre un export PDF / Impression",
                ].map((sugg, i) => (
                  <button
                    key={i}
                    onClick={() => handleModifyCode(sugg)}
                    className="px-2 py-0.5 rounded bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-800 shrink-0 transition-colors"
                  >
                    + {sugg}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab Content 2: Code Editor View */}
        {activeTab === 'code' && (
          <div className="flex-1 p-4 bg-slate-950 font-mono text-xs text-slate-200 overflow-auto max-h-[550px]">
            <pre className="whitespace-pre-wrap leading-relaxed select-text">
              {currentApp.htmlContent}
            </pre>
          </div>
        )}

        {/* Tab Content 3: CI/CD Pipeline & Manifest */}
        {activeTab === 'deploy' && (
          <div className="flex-1 p-6 bg-slate-950 space-y-6 overflow-auto max-h-[550px]">
            {/* Step Visualizer */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
                <span>Pipeline de Déploiement Continu Automatisé (CI/CD)</span>
                <span className="text-cyan-400 font-mono">
                  {deployStep >= 6 ? 'DÉPLOYÉ EN PRODUCTION' : isDeploying ? `ÉTAPE ${deployStep}/5` : 'PRÊT POUR ROLLOUT'}
                </span>
              </div>

              {/* Progress track */}
              <div className="grid grid-cols-5 gap-2 text-center text-[10px] font-mono">
                {['Audit WAF', 'Build OCI', 'Canary K8s', 'DNS Anycast', 'Live CDN'].map((stName, idx) => {
                  const isDone = deployStep > idx + 1;
                  const isCurrent = deployStep === idx + 1;
                  return (
                    <div
                      key={idx}
                      className={`p-2 rounded-lg border transition-all ${
                        isDone
                          ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400 font-bold'
                          : isCurrent
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-bold animate-pulse'
                          : 'bg-slate-950 border-slate-800 text-slate-500'
                      }`}
                    >
                      {stName}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Terminal Logs */}
            <div className="rounded-xl bg-black border border-slate-800 p-4 font-mono text-xs space-y-1 text-slate-300">
              <div className="text-slate-500 pb-2 border-b border-slate-800 flex items-center justify-between">
                <span>journalctl -u nexus-deployer.service -f</span>
                <span className="text-[10px] text-emerald-400">CONNECTÉ</span>
              </div>
              {deployLogs.map((log, index) => (
                <div key={index} className="text-emerald-400/90 leading-relaxed">
                  {log}
                </div>
              ))}
              {deployLogs.length === 0 && (
                <div className="text-slate-600">En attente du déclenchement du déploiement...</div>
              )}
            </div>

            {/* Kubernetes Deployment Manifest */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                <span>Spécification Kubernetes (deploy.yaml)</span>
                <span className="text-cyan-400 font-mono text-[11px]">Multi-AZ Autoscaling</span>
              </div>
              <pre className="p-3 rounded-lg bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed border border-slate-800/80">
                {currentApp.deploymentManifest}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

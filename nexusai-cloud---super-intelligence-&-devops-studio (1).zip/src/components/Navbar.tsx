import React from 'react';
import { 
  Cpu, 
  ShieldCheck, 
  Zap, 
  Activity, 
  Search, 
  Server, 
  Sparkles,
  Command,
  Bell
} from 'lucide-react';
import { ActiveTab, AdminSettings } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  openCommandPalette: () => void;
  adminSettings: AdminSettings;
  setAdminSettings: React.Dispatch<React.SetStateAction<AdminSettings>>;
  liveRps: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  openCommandPalette,
  adminSettings,
  setAdminSettings,
  liveRps,
}) => {
  const accentColors = {
    cyan: 'from-cyan-500 to-blue-600 border-cyan-500/30 text-cyan-400',
    emerald: 'from-emerald-500 to-teal-600 border-emerald-500/30 text-emerald-400',
    violet: 'from-purple-500 to-indigo-600 border-purple-500/30 text-purple-400',
    amber: 'from-amber-500 to-orange-600 border-amber-500/30 text-amber-400',
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/80 backdrop-blur-xl px-4 lg:px-6 py-2.5 transition-colors">
      <div className="flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-600 shadow-lg shadow-cyan-500/20 ring-1 ring-white/20">
            <Cpu className="w-5 h-5 text-white animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                NexusAI Cloud
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-semibold tracking-wider uppercase rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                v4.5 Enterprise
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono hidden sm:block">
              Super-Intelligence • DevOps & Architecture Studio
            </p>
          </div>
        </div>

        {/* Global Search & Command trigger */}
        <button
          onClick={openCommandPalette}
          className="flex-1 max-w-md hidden md:flex items-center justify-between px-3.5 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 text-slate-400 text-xs hover:border-slate-700 hover:text-slate-200 transition-all group shadow-inner"
        >
          <div className="flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition-colors" />
            <span>Rechercher une commande, module, prompt ou métrique...</span>
          </div>
          <kbd className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] text-slate-300 font-mono">
            <Command className="w-2.5 h-2.5" /> K
          </kbd>
        </button>

        {/* Live System Telemetry Badges */}
        <div className="flex items-center gap-2.5">
          {/* RPS Indicator */}
          <div className="hidden lg:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-900/80 border border-slate-800 text-xs font-mono">
            <Activity className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
            <span className="text-slate-400">Trafic :</span>
            <span className="text-cyan-300 font-semibold">{liveRps.toLocaleString()} req/s</span>
          </div>

          {/* Cloud Health Pill */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Cloud Nominal</span>
            <span className="text-[10px] text-emerald-300/80 font-mono">99.99%</span>
          </div>

          {/* Unbounded Mode Badge */}
          <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-medium">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Mode Zéro Restriction : Actif</span>
          </div>

          {/* Theme Quick Switcher */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
            {(['cyan', 'emerald', 'violet', 'amber'] as const).map((accent) => (
              <button
                key={accent}
                onClick={() => setAdminSettings((prev) => ({ ...prev, themeAccent: accent }))}
                title={`Thème ${accent}`}
                className={`w-4 h-4 rounded-full transition-transform ${
                  accent === 'cyan'
                    ? 'bg-cyan-400'
                    : accent === 'emerald'
                    ? 'bg-emerald-400'
                    : accent === 'violet'
                    ? 'bg-purple-400'
                    : 'bg-amber-400'
                } ${adminSettings.themeAccent === accent ? 'scale-125 ring-2 ring-white/50' : 'opacity-60 hover:opacity-100'}`}
              />
            ))}
          </div>

          {/* Admin Avatar */}
          <div className="flex items-center gap-2 pl-1 border-l border-slate-800">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-xs font-bold text-white shadow-md">
              AD
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

import React, { useState } from 'react';
import { 
  Sliders, 
  Shield, 
  Cpu, 
  Lock, 
  Palette, 
  Download, 
  Check, 
  Save, 
  Sparkles, 
  RefreshCw,
  Server,
  Terminal,
  Database
} from 'lucide-react';
import { AdminSettings } from '../types';

interface AdminProps {
  settings: AdminSettings;
  setSettings: React.Dispatch<React.SetStateAction<AdminSettings>>;
}

export const AdminConsole: React.FC<AdminProps> = ({ settings, setSettings }) => {
  const [saved, setSaved] = useState(false);
  const [ipWhitelist, setIpWhitelist] = useState<string[]>([
    '10.0.0.0/8 (VPC Interne)',
    '192.168.1.0/24 (Bureaux DevOps)',
    '172.16.0.0/12 (Bastion SSH)',
  ]);
  const [newIp, setNewIp] = useState('');

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
  };

  const handleAddIp = () => {
    if (!newIp.trim()) return;
    setIpWhitelist([...ipWhitelist, newIp.trim()]);
    setNewIp('');
  };

  const handleRemoveIp = (index: number) => {
    setIpWhitelist(ipWhitelist.filter((_, i) => i !== index));
  };

  const handleExportAuditLogs = () => {
    const auditData = {
      timestamp: new Date().toISOString(),
      cluster: 'nexus-enterprise-k8s',
      adminUser: 'root-admin-01',
      settings,
      whitelist: ipWhitelist,
      securityStatus: 'SOC2-COMPLIANT-VERIFIED',
    };
    const blob = new Blob([JSON.stringify(auditData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexus-admin-audit-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="h-full flex flex-col p-4 lg:p-6 max-w-7xl mx-auto w-full space-y-6 overflow-y-auto">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-slate-950 to-indigo-950/40 border border-slate-800 p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
                <Sliders className="w-4 h-4 text-cyan-400" />
              </span>
              <span className="text-xs font-mono font-semibold tracking-wider uppercase text-cyan-400">
                Gouvernance Système • Console Administrateur
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Console d'Administration Personnalisable
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl mt-1 leading-relaxed">
              Contrôlez les seuils du moteur d'IA, les politiques de sécurité WAF, les limites d'autoscaling du cluster et personnalisez l'interface selon vos préférences.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportAuditLogs}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exporter Audit Logs (JSON)</span>
            </button>

            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all transform active:scale-95"
            >
              {saved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
              <span>{saved ? 'Enregistré !' : 'Enregistrer les Modifications'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Admin Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: IA & Moteur de Génération */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-md">
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-300 pb-2 border-b border-slate-800">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>Paramètres du Moteur d'Intelligence Artificielle</span>
          </div>

          <div className="space-y-4 text-xs">
            {/* Model select */}
            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Modèle de Fond (Gemini API) :</label>
              <select
                value={settings.aiModel}
                onChange={(e) => setSettings({ ...settings, aiModel: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500 cursor-pointer"
              >
                <option value="gemini-3.8-flash">gemini-3.8-flash (Recommandé • Ultra-Rapide & Polyvalent)</option>
                <option value="gemini-flash-latest">gemini-flash-latest (Alias)</option>
              </select>
            </div>

            {/* Creativity / Restrictions Mode */}
            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Mode de Liberté Conceptuelle / Restrictions :</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'unbounded', label: 'Zéro Restriction', sub: 'Non bridé' },
                  { id: 'balanced', label: 'Équilibré', sub: 'Standard' },
                  { id: 'strict', label: 'Strict Académique', sub: 'Normes ISO' },
                ].map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => setSettings({ ...settings, creativityMode: mode.id as any })}
                    className={`p-2 rounded-xl border text-center transition-all ${
                      settings.creativityMode === mode.id
                        ? 'bg-purple-950/60 border-purple-500 text-purple-300 font-bold shadow'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div>{mode.label}</div>
                    <div className="text-[10px] text-slate-400">{mode.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Temperature Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-300">
                <span>Température par Défaut (Aléatoire / Déterminisme) :</span>
                <span className="font-mono text-cyan-400 font-bold">{settings.temperature}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.5"
                step="0.05"
                value={settings.temperature}
                onChange={(e) => setSettings({ ...settings, temperature: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Infrastructure Cloud & Autoscaling */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-md">
          <div className="flex items-center gap-2 text-xs font-bold text-blue-300 pb-2 border-b border-slate-800">
            <Server className="w-4 h-4 text-blue-400" />
            <span>Mise à l'Échelle Kubernetes & Déploiement</span>
          </div>

          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">Replicas Minimum (Pods) :</label>
                <input
                  type="number"
                  min="1"
                  max="32"
                  value={settings.minReplicas}
                  onChange={(e) => setSettings({ ...settings, minReplicas: parseInt(e.target.value) || 1 })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">Replicas Maximum (Pic) :</label>
                <input
                  type="number"
                  min="16"
                  max="256"
                  value={settings.maxReplicas}
                  onChange={(e) => setSettings({ ...settings, maxReplicas: parseInt(e.target.value) || 64 })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono focus:outline-none"
                />
              </div>
            </div>

            {/* Auto Healing Toggle */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-slate-200">Auto-Guérison Continue (Self-Healing)</div>
                <div className="text-[10px] text-slate-400">Redémarrage et remplacement automatique des pods défaillants</div>
              </div>
              <input
                type="checkbox"
                checked={settings.autoHealing}
                onChange={(e) => setSettings({ ...settings, autoHealing: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Auto Deploy to Prod */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-slate-200">Déploiement Automatique en Production</div>
                <div className="text-[10px] text-slate-400">Canary rollout immédiat après validation des tests CI</div>
              </div>
              <input
                type="checkbox"
                checked={settings.autoDeployProd}
                onChange={(e) => setSettings({ ...settings, autoDeployProd: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Card 3: Sécurité WAF & Liste Blanche IP */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-md">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-300 pb-2 border-b border-slate-800">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Sécurité Zero-Trust & Restriction d'Accès</span>
          </div>

          <div className="space-y-4 text-xs">
            {/* WAF Level */}
            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Niveau d'Enforcement du WAF :</label>
              <select
                value={settings.wafLevel}
                onChange={(e) => setSettings({ ...settings, wafLevel: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-emerald-500 cursor-pointer"
              >
                <option value="standard">Standard (Bloque injections SQL & XSS basiques)</option>
                <option value="high">Élevé (Inspection heuristique L7 + Anti-DDoS adaptatif)</option>
                <option value="paranoid">Paranoïaque (mTLS strict + analyse comportementale IA)</option>
              </select>
            </div>

            {/* IP Whitelist */}
            <div className="space-y-2">
              <label className="text-slate-300 font-medium">Plages Réseau Autorisées (Whitelist Admin) :</label>
              <div className="space-y-1.5 max-h-32 overflow-y-auto">
                {ipWhitelist.map((ip, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300"
                  >
                    <span>{ip}</span>
                    <button
                      onClick={() => handleRemoveIp(i)}
                      className="text-rose-400 hover:text-rose-300 text-xs px-1"
                    >
                      Supprimer
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={newIp}
                  onChange={(e) => setNewIp(e.target.value)}
                  placeholder="Ex : 192.168.10.0/24"
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none"
                />
                <button
                  onClick={handleAddIp}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold"
                >
                  Ajouter
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Card 4: Personnalisation Interface & Thème */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-md">
          <div className="flex items-center gap-2 text-xs font-bold text-purple-300 pb-2 border-b border-slate-800">
            <Palette className="w-4 h-4 text-purple-400" />
            <span>Personnalisation de l'Interface Studio</span>
          </div>

          <div className="space-y-4 text-xs">
            <div className="space-y-2">
              <label className="text-slate-300 font-medium">Couleur d'Accentuation du Thème :</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { id: 'cyan', name: 'Cyber Cyan', border: 'border-cyan-500', color: 'bg-cyan-500' },
                  { id: 'emerald', name: 'Matrix Emerald', border: 'border-emerald-500', color: 'bg-emerald-500' },
                  { id: 'violet', name: 'Deep Violet', border: 'border-purple-500', color: 'bg-purple-500' },
                  { id: 'amber', name: 'Sunset Amber', border: 'border-amber-500', color: 'bg-amber-500' },
                ].map((th) => (
                  <button
                    key={th.id}
                    onClick={() => setSettings({ ...settings, themeAccent: th.id as any })}
                    className={`p-3 rounded-xl border text-center transition-all flex flex-col items-center gap-2 ${
                      settings.themeAccent === th.id
                        ? `${th.border} bg-slate-950 ring-2 ring-white/20 font-bold text-white`
                        : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full ${th.color} shadow`}></div>
                    <span className="text-[11px]">{th.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <div className="font-semibold text-slate-200">Mode Haute Densité DevOps</div>
              <p>L'interface s'adapte automatiquement aux écrans ultra-larges et mobiles avec animations accélérées matériellement.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

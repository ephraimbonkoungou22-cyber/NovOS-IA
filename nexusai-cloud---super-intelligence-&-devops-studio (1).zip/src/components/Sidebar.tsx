import React from 'react';
import { 
  Sparkles, 
  GraduationCap, 
  Layout, 
  Cloud, 
  Gauge, 
  BarChart3, 
  MessageSquareHeart, 
  GitBranch, 
  Sliders,
  ChevronRight,
  Shield,
  Layers,
  Wrench,
  Clock,
  Image as ImageIcon,
  FileText
} from 'lucide-react';
import { ActiveTab, AdminSettings } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  adminSettings: AdminSettings;
  incidentCount: number;
  feedbackCount: number;
}

interface NavItem {
  id: ActiveTab;
  label: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  badgeColor?: string;
  count?: number;
  alertCount?: number;
}

interface NavGroup {
  groupTitle: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  adminSettings,
  incidentCount,
  feedbackCount,
}) => {
  const getAccentClass = (tab: ActiveTab) => {
    if (activeTab !== tab) return 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60';
    switch (adminSettings.themeAccent) {
      case 'emerald':
        return 'bg-emerald-500/15 text-emerald-400 border-l-2 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.15)]';
      case 'violet':
        return 'bg-purple-500/15 text-purple-400 border-l-2 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.15)]';
      case 'amber':
        return 'bg-amber-500/15 text-amber-400 border-l-2 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.15)]';
      default:
        return 'bg-cyan-500/15 text-cyan-400 border-l-2 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.15)]';
    }
  };

  const navGroups: NavGroup[] = [
    {
      groupTitle: 'INTELLIGENCE MULTIMODALE',
      items: [
        {
          id: 'omni' as ActiveTab,
          label: 'Assistant IA & Chat',
          desc: 'Questions, raisonnement & création',
          icon: Sparkles,
          badge: 'Illimité',
          badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
        },
        {
          id: 'images' as ActiveTab,
          label: 'Studio Images IA',
          desc: 'Diffusion Flux & Canvas 4K',
          icon: ImageIcon,
          badge: 'Images HD',
          badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
        },
        {
          id: 'pdf' as ActiveTab,
          label: 'Générateur de PDF',
          desc: 'Rapports, cours & synthèses',
          icon: FileText,
          badge: 'Export A4',
          badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
        },
        {
          id: 'academic' as ActiveTab,
          label: 'Tuteur Académique',
          desc: 'Études complexes en temps réel',
          icon: GraduationCap,
          badge: 'Maths & STEM',
          badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
        },
      ],
    },
    {
      groupTitle: 'DÉVELOPPEMENT & CLOUD',
      items: [
        {
          id: 'appforge' as ActiveTab,
          label: 'Studio Web & Apps',
          desc: 'Génération & Déploiement auto',
          icon: Layout,
          badge: 'CI/CD Auto',
          badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
        },
        {
          id: 'cloud' as ActiveTab,
          label: 'Architecture Cloud',
          desc: 'Infrastructure évolutive & sécurisée',
          icon: Cloud,
          badge: 'Multi-AZ',
          badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
        },
        {
          id: 'maintenance' as ActiveTab,
          label: 'Auto-Maintenance',
          desc: 'Optimisation continue & self-healing',
          icon: Wrench,
          badge: '99.99%',
          badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
        },
      ],
    },
    {
      groupTitle: 'TÉLÉMÉTRIE & COLLABORATION',
      items: [
        {
          id: 'analytics' as ActiveTab,
          label: 'Tableau Analytique',
          desc: 'Monitoring système & performances',
          icon: BarChart3,
        },
        {
          id: 'feedback' as ActiveTab,
          label: 'Retours Directs',
          desc: 'Activité & satisfaction utilisateurs',
          icon: MessageSquareHeart,
          count: feedbackCount,
        },
        {
          id: 'collab' as ActiveTab,
          label: 'Équipe & Incidents',
          desc: 'Gestion versions Git & War Room',
          icon: GitBranch,
          alertCount: incidentCount,
        },
      ],
    },
    {
      groupTitle: 'GOUVERNANCE & CONTRÔLE',
      items: [
        {
          id: 'admin' as ActiveTab,
          label: 'Console Admin',
          desc: 'Paramètres personnalisables & quotas',
          icon: Sliders,
          badge: 'Root',
          badgeColor: 'bg-slate-700/50 text-slate-300 border-slate-600/50',
        },
      ],
    },
  ];

  return (
    <aside className="w-64 lg:w-72 border-r border-slate-800 bg-slate-950/95 flex flex-col shrink-0 select-none overflow-y-auto">
      {/* Platform Status Header */}
      <div className="p-3.5 m-3 rounded-xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800/80">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            Moteur Neuronal
          </span>
          <span className="text-emerald-400 font-mono font-semibold">Gemini 3.8</span>
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div className="bg-gradient-to-r from-cyan-400 to-indigo-500 h-full w-[94%] rounded-full animate-pulse"></div>
        </div>
        <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1 font-mono">
          <span>Temps de réponse : 18ms</span>
          <span>SLA : 99.998%</span>
        </div>
      </div>

      {/* Nav Menu */}
      <div className="flex-1 px-3 space-y-6 pb-6">
        {navGroups.map((group, idx) => (
          <div key={idx} className="space-y-1">
            <div className="px-3 py-1 text-[10px] font-bold tracking-wider text-slate-400 uppercase font-mono">
              {group.groupTitle}
            </div>
            <div className="space-y-1">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isSelected = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full group flex items-center justify-between px-3 py-2.5 rounded-lg text-left transition-all duration-150 ${getAccentClass(
                      item.id
                    )}`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`p-1.5 rounded-md transition-colors ${
                          isSelected
                            ? 'bg-white/10 text-white'
                            : 'bg-slate-900 text-slate-400 group-hover:text-slate-200'
                        }`}
                      >
                        <Icon className="w-4 h-4 shrink-0" />
                      </div>
                      <div className="truncate">
                        <div className="text-xs font-semibold tracking-wide truncate">
                          {item.label}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate opacity-85 group-hover:opacity-100">
                          {item.desc}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0 ml-2">
                      {item.badge && (
                        <span
                          className={`text-[9px] font-medium px-1.5 py-0.5 rounded border ${item.badgeColor}`}
                        >
                          {item.badge}
                        </span>
                      )}
                      {item.count !== undefined && (
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                          {item.count}
                        </span>
                      )}
                      {item.alertCount !== undefined && item.alertCount > 0 && (
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                          {item.alertCount} P1
                        </span>
                      )}
                      <ChevronRight
                        className={`w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity ${
                          isSelected ? 'opacity-100' : ''
                        }`}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Cluster Footer */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/80 text-[11px] text-slate-400 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
          <span className="font-mono">Cluster eu-west3</span>
        </div>
        <span className="text-slate-400 font-mono text-[10px]">Zero-Lock</span>
      </div>
    </aside>
  );
};

import React, { useState } from 'react';
import { 
  Cloud, 
  ShieldCheck, 
  Server, 
  Database, 
  Cpu, 
  Globe, 
  Lock, 
  ArrowRight, 
  Layers, 
  Zap, 
  CheckCircle2, 
  AlertTriangle,
  Sliders,
  HardDrive
} from 'lucide-react';

export const CloudArchitecture: React.FC = () => {
  const [trafficLoad, setTrafficLoad] = useState<number>(45000); // req/s
  const [activeRegions, setActiveRegions] = useState<{ [key: string]: boolean }>({
    'eu-west3': true,
    'us-east1': true,
    'asia-east1': true,
  });
  const [wafEnforced, setWafEnforced] = useState(true);
  const [ddosShield, setDdosShield] = useState(true);

  // Computed metrics based on traffic load
  const activeRegionCount = Object.values(activeRegions).filter(Boolean).length || 1;
  const loadPerRegion = Math.round(trafficLoad / activeRegionCount);
  const podsRequired = Math.max(4, Math.ceil(trafficLoad / 3500));
  const estimatedLatency = Math.max(8, Math.round(14 + (trafficLoad / 100000) * 8));

  const toggleRegion = (region: string) => {
    setActiveRegions((prev) => {
      const next = { ...prev, [region]: !prev[region] };
      // Ensure at least 1 region remains active
      if (!Object.values(next).some(Boolean)) {
        return prev;
      }
      return next;
    });
  };

  return (
    <div className="h-full flex flex-col p-4 lg:p-6 max-w-7xl mx-auto w-full space-y-6 overflow-y-auto">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-cyan-950/50 border border-blue-500/20 p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-500/30">
                <Cloud className="w-4 h-4 text-blue-400" />
              </span>
              <span className="text-xs font-mono font-semibold tracking-wider uppercase text-blue-400">
                Infrastructure Distribuée Haute Sécurité
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Architecture Cloud Évolutive & Sécurisée
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl mt-1 leading-relaxed">
              Topologie multi-région à mise à l'échelle automatique (Autoscaling), pare-feu applicatif Zero-Trust (WAF), chiffrement KMS et tolérance de panne instantanée.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/80 px-3.5 py-2 rounded-xl border border-blue-500/30 self-start md:self-auto">
            <Lock className="w-4 h-4 text-emerald-400" />
            <div className="text-xs">
              <div className="font-bold text-slate-200">Zero-Trust Enforced</div>
              <div className="text-[10px] text-emerald-400 font-mono">SOC2 • ISO 27001 Compliant</div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Controls & Autoscaling Simulation Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Load simulation slider */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-200">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              Simulateur de Charge Trafic
            </span>
            <span className="font-mono text-cyan-400 text-sm">{trafficLoad.toLocaleString()} req/s</span>
          </div>

          <input
            type="range"
            min="1000"
            max="250000"
            step="2000"
            value={trafficLoad}
            onChange={(e) => setTrafficLoad(parseInt(e.target.value))}
            className="w-full accent-cyan-400 cursor-pointer"
          />

          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>Min : 1k req/s</span>
            <span>Pics mondiaux : 250k req/s</span>
          </div>
        </div>

        {/* Dynamic Scaling Metrics */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-around">
          <div className="text-center">
            <div className="text-xs text-slate-400">Pods K8s Actifs</div>
            <div className="text-xl font-extrabold text-cyan-400 mt-1 font-mono">{podsRequired}</div>
            <div className="text-[10px] text-emerald-400 font-semibold mt-0.5">Auto-scale HPA</div>
          </div>
          <div className="w-px h-10 bg-slate-800"></div>
          <div className="text-center">
            <div className="text-xs text-slate-400">Latence Moyenne</div>
            <div className="text-xl font-extrabold text-emerald-400 mt-1 font-mono">{estimatedLatency} ms</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Anycast Edge</div>
          </div>
          <div className="w-px h-10 bg-slate-800"></div>
          <div className="text-center">
            <div className="text-xs text-slate-400">Uptime Cluster</div>
            <div className="text-xl font-extrabold text-white mt-1 font-mono">99.998%</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">SLA Garanti</div>
          </div>
        </div>

        {/* Multi-Region Failover Toggles */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
          <div className="text-xs font-bold text-slate-200 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              Régions Cloud Actives (Failover)
            </span>
            <span className="text-[10px] font-mono text-slate-400">{activeRegionCount} Actives</span>
          </div>

          <div className="flex items-center gap-2">
            {[
              { id: 'eu-west3', label: 'Francfort (EU)' },
              { id: 'us-east1', label: 'Virginie (US)' },
              { id: 'asia-east1', label: 'Tokyo (APAC)' },
            ].map((reg) => (
              <button
                key={reg.id}
                onClick={() => toggleRegion(reg.id)}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold transition-all border ${
                  activeRegions[reg.id]
                    ? 'bg-blue-600/20 border-blue-500/50 text-blue-300'
                    : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-300'
                }`}
              >
                {reg.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Architecture Blueprint Topology Diagram */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Diagramme Topologique de l'Infrastructure en Temps Réel</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">Flux de requêtes chiffré de bout en bout (Zero-Trust mTLS)</p>
          </div>
          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-medium">
            Trafic Chiffré TLS 1.3
          </span>
        </div>

        {/* Visual Pipeline Nodes */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
          {/* Node 1: Edge CDN */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 relative group hover:border-cyan-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <Globe className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-slate-100">1. Edge CDN Anycast</div>
            <p className="text-[11px] text-slate-400">280+ points de présence avec mise en cache statique (Cache Hit : 98.4%).</p>
            <div className="text-[10px] text-cyan-400 font-mono">Brotli / HTTP/3</div>
          </div>

          {/* Node 2: WAF & Security */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 relative group hover:border-emerald-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-slate-100">2. WAF & DDoS Shield</div>
            <p className="text-[11px] text-slate-400">Filtrage des attaques L3/L4/L7, botnets, injections SQL et rate-limiting adaptatif.</p>
            <div className="text-[10px] text-emerald-400 font-mono">1,429 attaques bloquées</div>
          </div>

          {/* Node 3: Ingress Load Balancer */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 relative group hover:border-purple-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center">
              <Zap className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-slate-100">3. Envoy Load Balancer</div>
            <p className="text-[11px] text-slate-400">Répartition intelligente des requêtes basée sur la santé des pods et la latence régionale.</p>
            <div className="text-[10px] text-purple-400 font-mono">{loadPerRegion.toLocaleString()} req/s/région</div>
          </div>

          {/* Node 4: Kubernetes Cluster */}
          <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/40 space-y-2 relative group shadow-lg shadow-cyan-500/5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Cpu className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-cyan-300">4. Cluster Kubernetes K8s</div>
            <p className="text-[11px] text-slate-300">Conteneurs applicatifs auto-scalés (HPA) avec Rolling Updates sans coupure.</p>
            <div className="text-[10px] text-cyan-400 font-mono font-bold">{podsRequired} Pods en ligne</div>
          </div>

          {/* Node 5: Data & Storage */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 relative group hover:border-indigo-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-slate-100">5. Multi-AZ Cloud SQL</div>
            <p className="text-[11px] text-slate-400">PostgreSQL haute performance répliqué + Redis Cluster pour cache mémoire ultra-rapide.</p>
            <div className="text-[10px] text-indigo-400 font-mono">Chiffrement AES-256 KMS</div>
          </div>
        </div>

        {/* Security Controls & Audit */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-800">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">Règles WAF Strictes</div>
              <div className="text-[10px] text-slate-400">Inspection heuristique et heuristiques Zero-Day</div>
            </div>
            <button
              onClick={() => setWafEnforced(!wafEnforced)}
              className={`px-2.5 py-1 rounded text-xs font-bold ${
                wafEnforced ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {wafEnforced ? 'ACTIF' : 'PAUSE'}
            </button>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">Protection Anti-DDoS Anycast</div>
              <div className="text-[10px] text-slate-400">Capacité d'absorption jusqu'à 3.2 Tbps</div>
            </div>
            <button
              onClick={() => setDdosShield(!ddosShield)}
              className={`px-2.5 py-1 rounded text-xs font-bold ${
                ddosShield ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {ddosShield ? 'VERROUILLÉ' : 'DÉSACTIVÉ'}
            </button>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">Clés de Chiffrement KMS</div>
              <div className="text-[10px] text-slate-400">Rotation automatique tous les 90 jours</div>
            </div>
            <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-mono">
              FIPS 140-2
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

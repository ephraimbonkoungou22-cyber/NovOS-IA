import React, { useState } from 'react';
import { 
  GitBranch, 
  AlertTriangle, 
  CheckCircle2, 
  Terminal, 
  Users, 
  GitCommit as GitCommitIcon, 
  GitPullRequest, 
  RefreshCw, 
  Play, 
  Sparkles, 
  Clock, 
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { Incident, GitCommit } from '../types';

interface CollabProps {
  incidents: Incident[];
  setIncidents: React.Dispatch<React.SetStateAction<Incident[]>>;
}

export const CollaborationHub: React.FC<CollabProps> = ({ incidents, setIncidents }) => {
  const [subTab, setSubTab] = useState<'incidents' | 'git' | 'team'>('incidents');
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(incidents[0] || null);
  const [analyzingIncident, setAnalyzingIncident] = useState(false);
  const [remediating, setRemediating] = useState(false);
  const [activeBranch, setActiveBranch] = useState('main');

  const teamMembers = [
    { name: 'Alexandre Roy', role: 'Staff SRE & Incident Commander', status: 'En ligne - War Room', avatar: 'AR', color: 'from-cyan-500 to-blue-600' },
    { name: 'Sarah Benali', role: 'Principal Cloud Architect', status: 'En ligne - Review K8s', avatar: 'SB', color: 'from-purple-500 to-pink-600' },
    { name: 'Thomas Keller', role: 'AI & Inference Lead', status: 'En ligne - Tuning Gemini', avatar: 'TK', color: 'from-emerald-500 to-teal-600' },
    { name: 'Inès Chevalier', role: 'Senior Frontend Engineer', status: 'En ligne - AppForge Studio', avatar: 'IC', color: 'from-amber-500 to-orange-600' },
  ];

  const commits: GitCommit[] = [
    { hash: 'e89a42f', branch: 'main', author: 'Sarah Benali', message: 'feat(cloud): activer autoscaling dynamique 128 pods pour cluster eu-west3', timestamp: 'Il y a 12 min', changes: { added: 142, deleted: 18 } },
    { hash: 'c41f77d', branch: 'main', author: 'Thomas Keller', message: 'perf(inference): optimisation du streaming des tokens pour le solveur académique', timestamp: 'Il y a 45 min', changes: { added: 89, deleted: 12 } },
    { hash: 'a1b920e', branch: 'feature/quantum-solver', author: 'Alexandre Roy', message: 'fix(sre): durcissement des règles WAF et mitigation des faux positifs', timestamp: 'Il y a 2h', changes: { added: 34, deleted: 5 } },
    { hash: '990d18b', branch: 'main', author: 'Inès Chevalier', message: 'ui(appforge): ajout du mode mobile et iframe sandboxing', timestamp: 'Il y a 3h', changes: { added: 210, deleted: 42 } },
  ];

  const handleAnalyzeIncident = async (inc: Incident) => {
    setAnalyzingIncident(true);
    setSelectedIncident(inc);

    try {
      const res = await fetch('/api/ai/incident-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          incidentTitle: inc.title,
          severity: inc.severity,
          errorLogs: inc.logs,
          systemContext: `Service: ${inc.service}, Région: ${inc.region}`,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setIncidents((prev) =>
          prev.map((item) =>
            item.id === inc.id
              ? {
                  ...item,
                  status: "En cours d'analyse",
                  aiDiagnostic: data.analysis,
                }
              : item
          )
        );
        setSelectedIncident((prev) => (prev ? { ...prev, aiDiagnostic: data.analysis } : null));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAnalyzingIncident(false);
    }
  };

  const handleApplyFix = (incId: string) => {
    setRemediating(true);
    setTimeout(() => {
      setIncidents((prev) =>
        prev.map((item) =>
          item.id === incId
            ? { ...item, status: 'Rollback effectué' }
            : item
        )
      );
      if (selectedIncident && selectedIncident.id === incId) {
        setSelectedIncident((prev) => (prev ? { ...prev, status: 'Rollback effectué' } : null));
      }
      setRemediating(false);
    }, 1400);
  };

  return (
    <div className="h-full flex flex-col p-4 lg:p-6 max-w-7xl mx-auto w-full space-y-6 overflow-y-auto">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/70 to-purple-950/60 border border-indigo-500/20 p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                <GitBranch className="w-4 h-4 text-indigo-400" />
              </span>
              <span className="text-xs font-mono font-semibold tracking-wider uppercase text-indigo-400">
                Collaboration Technique • Git & Incident War Room
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Gestion des Versions & Résolution d'Incidents SRE
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl mt-1 leading-relaxed">
              Espace collaboratif pour équipes d'ingénierie : arbre de commits Git, branches, diagnostics d'incidents automatisés par l'IA et rollbacks en 1 clic.
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/90 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setSubTab('incidents')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                subTab === 'incidents'
                  ? 'bg-rose-600 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>War Room Incidents ({incidents.filter(i => i.status !== 'Rollback effectué' && i.status !== 'Résolu').length})</span>
            </button>
            <button
              onClick={() => setSubTab('git')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                subTab === 'git'
                  ? 'bg-indigo-600 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <GitCommitIcon className="w-3.5 h-3.5" />
              <span>Gestion Versions (Git)</span>
            </button>
            <button
              onClick={() => setSubTab('team')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                subTab === 'team'
                  ? 'bg-cyan-600 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Équipe Active ({teamMembers.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Subtab 1: War Room Incidents */}
      {subTab === 'incidents' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Incident List */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-200">Incidents Détectés par la Télémétrie</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-300">
                Temps Réel
              </span>
            </div>

            <div className="space-y-2.5">
              {incidents.map((inc) => (
                <button
                  key={inc.id}
                  onClick={() => setSelectedIncident(inc)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                    selectedIncident?.id === inc.id
                      ? 'bg-slate-950 border-rose-500/60 shadow-lg shadow-rose-500/10'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-slate-100">{inc.title}</span>
                    <span
                      className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase ${
                        inc.severity.startsWith('P1')
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {inc.severity}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span>{inc.service} • {inc.region}</span>
                    <span
                      className={`font-semibold ${
                        inc.status === 'Rollback effectué'
                          ? 'text-emerald-400'
                          : inc.status === 'En cours d\'analyse'
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {inc.status}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Incident Diagnostic Detail & AI Remediation */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
            {selectedIncident ? (
              <>
                <div className="flex items-start justify-between pb-3 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-rose-400 uppercase">
                        [{selectedIncident.id}]
                      </span>
                      <h2 className="text-base font-bold text-white">{selectedIncident.title}</h2>
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5 font-mono">
                      Service affecté : <span className="text-slate-200 font-semibold">{selectedIncident.service}</span> • Détecté : {selectedIncident.detectedAt}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleAnalyzeIncident(selectedIncident)}
                      disabled={analyzingIncident}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow disabled:opacity-50 transition-all"
                    >
                      {analyzingIncident ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Sparkles className="w-3.5 h-3.5" />
                      )}
                      <span>Diagnostic Cause Racine (IA)</span>
                    </button>

                    {selectedIncident.status !== 'Rollback effectué' && (
                      <button
                        onClick={() => handleApplyFix(selectedIncident.id)}
                        disabled={remediating}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 text-white font-semibold text-xs shadow-md shadow-rose-600/30 disabled:opacity-50 transition-all"
                      >
                        {remediating ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Play className="w-3.5 h-3.5" />
                        )}
                        <span>Rollback & Auto-Remédiation</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Raw Logs */}
                <div className="space-y-1.5">
                  <div className="text-xs font-mono text-slate-400 flex items-center justify-between">
                    <span>Logs d'Erreurs Capturés (Stacktrace / Journald) :</span>
                    <span className="text-[10px] text-rose-400 font-bold">Traceback</span>
                  </div>
                  <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-rose-300 font-mono overflow-x-auto leading-relaxed">
                    {selectedIncident.logs}
                  </pre>
                </div>

                {/* AI Diagnostic View */}
                {selectedIncident.aiDiagnostic ? (
                  <div className="p-4 rounded-xl bg-slate-950 border border-indigo-500/40 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-indigo-300">
                      <Sparkles className="w-4 h-4 text-indigo-400" />
                      <span>Rapport d'Analyse SRE par Gemini 3.8 Flash</span>
                    </div>
                    <div className="text-xs text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                      {selectedIncident.aiDiagnostic}
                    </div>
                  </div>
                ) : (
                  <div className="p-6 rounded-xl bg-slate-950/60 border border-dashed border-slate-800 text-center text-xs text-slate-500 space-y-2">
                    <Terminal className="w-6 h-6 mx-auto text-slate-600" />
                    <div>Cliquez sur "Diagnostic Cause Racine (IA)" pour lancer l'analyse automatisée.</div>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-12 text-xs text-slate-500">
                Sélectionnez un incident pour afficher la fiche de remédiation.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Subtab 2: Version Control (Git) */}
      {subTab === 'git' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">Branche Active :</span>
              <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800 font-mono text-cyan-300 font-semibold">
                <GitBranch className="w-3.5 h-3.5 text-cyan-400" />
                <select
                  value={activeBranch}
                  onChange={(e) => setActiveBranch(e.target.value)}
                  className="bg-transparent border-0 focus:outline-none cursor-pointer"
                >
                  <option value="main">main (production)</option>
                  <option value="staging-edge">staging-edge</option>
                  <option value="v4.5-stable">v4.5-stable</option>
                  <option value="feature/quantum-solver">feature/quantum-solver</option>
                </select>
              </div>
            </div>

            <span className="text-xs font-mono text-emerald-400">Sync avec remote origin : OK (0 divergence)</span>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-300">Historique des Derniers Commits</h3>
            <div className="space-y-2">
              {commits.map((c) => (
                <div
                  key={c.hash}
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-start gap-3">
                    <span className="font-mono text-cyan-400 font-bold px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-800 shrink-0">
                      {c.hash}
                    </span>
                    <div>
                      <div className="font-semibold text-slate-200">{c.message}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        Auteur : <strong className="text-slate-300">{c.author}</strong> • Branche : {c.branch} • {c.timestamp}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 font-mono text-[10px] self-end sm:self-auto">
                    <span className="text-emerald-400">+{c.changes.added}</span>
                    <span className="text-rose-400">-{c.changes.deleted}</span>
                    <button className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 hover:text-white">
                      Inspecter Diff
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Subtab 3: Team Collaboration */}
      {subTab === 'team' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {teamMembers.map((member, i) => (
            <div
              key={i}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4 hover:border-slate-700 transition-all shadow-md"
            >
              <div
                className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${member.color} flex items-center justify-center font-bold text-white text-base shadow`}
              >
                {member.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-100">{member.name}</h3>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                </div>
                <div className="text-xs text-slate-400 mt-0.5">{member.role}</div>
                <div className="text-[11px] text-cyan-300/80 font-mono mt-1">{member.status}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

import React, { useState, useRef } from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  Calculator, 
  Atom, 
  Dna, 
  Cpu, 
  Send, 
  RefreshCw, 
  HelpCircle, 
  Award, 
  CheckCircle2, 
  Sparkles, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Image as ImageIcon,
  MessageSquare,
  Bot
} from 'lucide-react';
import { AcademicQuery } from '../types';

export const AcademicTutor: React.FC = () => {
  const [subject, setSubject] = useState('Mathématiques Supérieures');
  const [level, setLevel] = useState('Classes Préparatoires (MPSI / PCSI / MP*)');
  const [problem, setProblem] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeQuery, setActiveQuery] = useState<AcademicQuery | null>(null);
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Follow-up Q&A
  const [followUpQuestion, setFollowUpQuestion] = useState('');
  const [followUpAnswers, setFollowUpAnswers] = useState<{ q: string; a: string }[]>([]);
  const [followUpLoading, setFollowUpLoading] = useState(false);

  // Image vision attachment
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const subjects = [
    { name: 'Mathématiques Supérieures', icon: Calculator, color: 'text-indigo-400' },
    { name: 'Physique Quantique & Théorique', icon: Atom, color: 'text-cyan-400' },
    { name: 'Chimie Organique & Moléculaire', icon: Dna, color: 'text-emerald-400' },
    { name: 'Informatique & Algorithmique', icon: Cpu, color: 'text-purple-400' },
    { name: 'Biologie & Génétique Moléculaire', icon: BookOpen, color: 'text-rose-400' },
  ];

  const levels = [
    'Classes Préparatoires (MPSI / PCSI / MP*)',
    'Université Licence / Master (L3/M1/M2)',
    'Doctorat & Recherche Fondamentale',
    'Terminale Scientifique / Maths Expertes',
  ];

  const complexPresets = [
    {
      subject: 'Mathématiques Supérieures',
      title: 'Équation de la Chaleur & Transformée de Fourier',
      text: "Résoudre l'équation de la chaleur unidimensionnelle $\\partial_t u = \\alpha \\partial_{xx} u$ sur $\\mathbb{R}$ avec la condition initiale $u(x,0) = e^{-x^2}$. Démontrer chaque étape à l'aide de la transformée de Fourier et du théorème de convolution.",
    },
    {
      subject: 'Physique Quantique & Théorique',
      title: 'Oscillateur Harmonique & Opérateurs d\'Échelle',
      text: "Démontrer la quantification de l'énergie de l'oscillateur harmonique quantique $E_n = \\hbar \\omega (n + 1/2)$ à l'aide des opérateurs d'annihilation $a$ et de création $a^\\dagger$. Expliciter le commutateur $[a, a^\\dagger] = 1$.",
    },
    {
      subject: 'Chimie Organique & Moléculaire',
      title: 'Mécanisme SN1 vs SN2 & Stéréochimie',
      text: "Comparer en détail les mécanismes de substitution nucléophile SN1 et SN2 (cinétique d'ordre 1 vs 2, intermédiaires carbocationiques, inversion de Walden vs racémisation). Donner un exemple concret avec le 2-bromobutane.",
    },
    {
      subject: 'Informatique & Algorithmique',
      title: 'Complexité & Correction Algorithme de Dijkstra',
      text: "Démontrer formellement par récurrence la correction de l'algorithme de Dijkstra pour les chemins les plus courts dans un graphe orienté à poids positifs. Détailler l'impact d'un tas binaire vs tas de Fibonacci sur la complexité.",
    },
  ];

  const speakSolution = (text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }
    const clean = text.replace(/[#*`$\-_]/g, ' ').slice(0, 450);
    const u = new SpeechSynthesisUtterance(clean);
    u.lang = 'fr-FR';
    u.rate = 1.0;
    u.onstart = () => setIsSpeaking(true);
    u.onend = () => setIsSpeaking(false);
    u.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(u);
  };

  const handleSolve = async (customProblem?: string, customSubject?: string) => {
    const textToSolve = customProblem || problem;
    const currentSubject = customSubject || subject;
    if (!textToSolve.trim() && !attachedImage) return;

    setLoading(true);
    setFollowUpAnswers([]);

    try {
      let finalSolution = '';

      if (attachedImage) {
        const res = await fetch('/api/ai/vision-solve', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: attachedImage,
            prompt: `Matière : ${currentSubject}. Niveau : ${level}. Résous complètement l'exercice présenté dans cette image avec démonstration formelle pas-à-pas et formules explicites : "${textToSolve}"`,
          }),
        });
        const data = await res.json();
        finalSolution = data.analysis;
      } else {
        const res = await fetch('/api/ai/academic-tutor', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            subject: currentSubject,
            level,
            problem: textToSolve,
          }),
        });
        const data = await res.json();
        finalSolution = data.solution;
      }

      setActiveQuery({
        id: Date.now().toString(),
        subject: currentSubject,
        level,
        problem: textToSolve || "Problème d'après image",
        solution: finalSolution,
        timestamp: new Date().toLocaleTimeString(),
      });
    } catch (err: any) {
      alert(`Erreur : ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleFollowUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!followUpQuestion.trim() || !activeQuery) return;

    setFollowUpLoading(true);
    const q = followUpQuestion;
    setFollowUpQuestion('');

    try {
      const res = await fetch('/api/ai/omni-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Dans le cadre de la résolution du problème suivant : "${activeQuery.problem}"
Voici la solution déjà établie :
${activeQuery.solution.slice(0, 500)}...

L'étudiant pose cette question de clarification spécifique :
"${q}"

Réponds avec une grande clarté pédagogique, de façon concise et encourageante en français.`,
          temperature: 0.3,
        }),
      });

      const data = await res.json();
      setFollowUpAnswers((prev) => [...prev, { q, a: data.result || 'Précision fournie.' }]);
    } catch (err: any) {
      setFollowUpAnswers((prev) => [...prev, { q, a: `Erreur : ${err.message}` }]);
    } finally {
      setFollowUpLoading(false);
    }
  };

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setAttachedImage(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleCopy = () => {
    if (!activeQuery) return;
    navigator.clipboard.writeText(activeQuery.solution);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col p-4 lg:p-6 max-w-7xl mx-auto w-full space-y-6 overflow-y-auto">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-indigo-950/70 via-slate-900 to-blue-950/50 border border-indigo-500/20 p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                <GraduationCap className="w-4 h-4 text-indigo-400" />
              </span>
              <span className="text-xs font-mono font-semibold tracking-wider uppercase text-indigo-400">
                Système Polymathic STEM & Humanités
              </span>
            </div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              Tuteur Académique Intelligent Temps Réel
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl mt-1 leading-relaxed">
              Résolution pas-à-pas avec rigueur mathématique, lecture vocale des démonstrations, analyse photo d'exercices et dialogue pédagogique interactif.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/80 px-3.5 py-2 rounded-xl border border-indigo-500/30 self-start md:self-auto">
            <Award className="w-4 h-4 text-indigo-400" />
            <div className="text-xs">
              <div className="font-bold text-slate-200">Précision Analytique 100%</div>
              <div className="text-[10px] text-slate-400">LaTeX, Preuves Formelles & Audio</div>
            </div>
          </div>
        </div>
      </div>

      {/* Subject & Level Selector */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          {subjects.map((s) => {
            const Icon = s.icon;
            const active = subject === s.name;
            return (
              <button
                key={s.name}
                onClick={() => setSubject(s.name)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-medium transition-all ${
                  active
                    ? 'bg-indigo-950/60 border-indigo-500/60 text-white shadow-md shadow-indigo-500/10'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${s.color}`} />
                <span>{s.name}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2 bg-slate-900 px-3 py-2 rounded-xl border border-slate-800 text-xs">
          <span className="text-slate-400 shrink-0">Niveau :</span>
          <select
            value={level}
            onChange={(e) => setLevel(e.target.value)}
            className="bg-slate-950 text-indigo-300 font-medium rounded-lg px-2 py-1 border border-slate-800 focus:outline-none cursor-pointer"
          >
            {levels.map((lvl) => (
              <option key={lvl} value={lvl}>
                {lvl}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Complex Presets */}
      <div className="space-y-2">
        <div className="text-[11px] font-mono uppercase text-slate-400 flex items-center gap-1.5">
          <BookOpen className="w-3 h-3 text-indigo-400" />
          Problèmes Types Pré-chargés en 1 Clic :
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {complexPresets.map((presetItem, idx) => (
            <button
              key={idx}
              onClick={() => {
                setSubject(presetItem.subject);
                setProblem(presetItem.text);
                setAttachedImage(null);
                handleSolve(presetItem.text, presetItem.subject);
              }}
              className="text-left p-3 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-indigo-500/40 text-slate-300 hover:text-white transition-all group shadow-sm flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-indigo-300 group-hover:text-indigo-200">
                  {presetItem.title}
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-400 border border-indigo-800">
                  {presetItem.subject.split(' ')[0]}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed font-mono">
                {presetItem.text}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Input Box with Image Attachment */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-200">
            Énoncé de l'exercice ou question d'étude :
          </label>

          {/* Photo attach button */}
          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImagePick}
              accept="image/*"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs transition-colors ${
                attachedImage
                  ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/50'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border-slate-800'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>{attachedImage ? 'Photo jointe (Prête)' : 'Joindre une photo d\'exercice'}</span>
            </button>
            {attachedImage && (
              <button
                onClick={() => setAttachedImage(null)}
                className="text-[11px] text-rose-400 hover:underline"
              >
                Retirer
              </button>
            )}
          </div>
        </div>

        {attachedImage && (
          <div className="p-2 rounded-xl bg-slate-950 border border-indigo-500/30 flex items-center gap-3">
            <img src={attachedImage} alt="Attachment" className="h-16 w-16 object-cover rounded-lg" />
            <div className="text-xs text-slate-300">
              <span className="font-semibold text-indigo-300">Image prête pour résolution multimodale.</span>
              <p className="text-[11px] text-slate-400">L'IA analysera le schéma manuscrit en même temps que votre consigne.</p>
            </div>
          </div>
        )}

        <textarea
          value={problem}
          onChange={(e) => setProblem(e.target.value)}
          placeholder="Exemple : Démontrer l'inégalité de Cauchy-Schwarz pour des fonctions dans L^2, en précisant les cas d'égalité et la signification géométrique..."
          rows={3}
          className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 resize-none font-sans"
        />

        <div className="flex items-center justify-between pt-1">
          <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Moteur d'inférence académique Gemini 3.8 Flash</span>
          </span>

          <button
            onClick={() => handleSolve()}
            disabled={loading || (!problem.trim() && !attachedImage)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 text-white font-semibold text-xs shadow-lg shadow-indigo-600/25 disabled:opacity-40 transition-all"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Résolution & Démonstration en direct...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Résoudre avec Démonstration Formelle</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Solution View & Interactive Follow-up Q&A */}
      {activeQuery && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col space-y-4 p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-indigo-300">Démonstration & Analyse Scientifique</span>
              <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-400 border border-indigo-800 font-mono text-[10px]">
                {activeQuery.subject}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => speakSolution(activeQuery.solution)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs transition-colors border ${
                  isSpeaking
                    ? 'bg-rose-500 text-white border-rose-400'
                    : 'bg-slate-950 hover:bg-slate-800 text-slate-300 border-slate-800'
                }`}
              >
                {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-indigo-400" />}
                <span>{isSpeaking ? 'Arrêter Voix' : 'Écouter Explication'}</span>
              </button>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copié' : 'Copier'}</span>
              </button>
            </div>
          </div>

          {/* Solution Body */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800/80 text-xs sm:text-sm text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
            {activeQuery.solution}
          </div>

          {/* Follow-up Q&A stream */}
          {followUpAnswers.length > 0 && (
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Clarifications Pédagogiques avec l'IA</span>
              </h3>
              {followUpAnswers.map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-indigo-500/30 space-y-2 text-xs">
                  <div className="font-semibold text-slate-300 flex items-center gap-2">
                    <span className="text-indigo-400 font-mono">Q:</span> {item.q}
                  </div>
                  <div className="text-slate-200 leading-relaxed pl-4 border-l-2 border-indigo-500/50">
                    {item.a}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Follow-up input form */}
          <form onSubmit={handleFollowUp} className="flex gap-2 pt-2 border-t border-slate-800">
            <input
              type="text"
              value={followUpQuestion}
              onChange={(e) => setFollowUpQuestion(e.target.value)}
              placeholder="Poser une question de suivi sur cette démonstration (ex : Pourquoi cette intégrale converge ?)..."
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={followUpLoading || !followUpQuestion.trim()}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold disabled:opacity-40 transition-all flex items-center gap-1.5 shrink-0"
            >
              {followUpLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              <span>Demander</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { GeneratedPdfDoc, GeneratedPdfSection } from '../types';
import { buildPdfDocument } from '../utils/pdfGenerator';
import {
  FileText,
  Download,
  Sparkles,
  BookOpen,
  Briefcase,
  Cpu,
  GraduationCap,
  RefreshCw,
  Edit3,
  Check,
  Eye,
  Plus,
  Trash2,
  Share2,
} from 'lucide-react';

const TEMPLATES = [
  {
    id: 'course_summary',
    label: 'Fiche de Révision Scolaire',
    icon: GraduationCap,
    desc: 'Idéal pour le Bac, Prépa, Université (définitions, théorèmes, méthode)',
    defaultTopic: 'La mécanique quantique et le principe de superposition de Schrödinger',
  },
  {
    id: 'technical_audit',
    label: 'Rapport Technique & Audit SRE',
    icon: Cpu,
    desc: 'Architecture distribuée, métriques, résilience, et plan d\'action',
    defaultTopic: 'Audit d\'infrastructure Cloud multi-région et résilience Kubernetes',
  },
  {
    id: 'executive_summary',
    label: 'Note de Synthèse Exécutive',
    icon: FileText,
    desc: 'Décisionnaires, prospective stratégique, analyse d\'impact économique',
    defaultTopic: 'L\'essor de l\'intelligence artificielle générative et son impact économique en 2026',
  },
  {
    id: 'commercial_proposal',
    label: 'Proposition Commerciale & Devis',
    icon: Briefcase,
    desc: 'Cahier des charges, livrables, calendrier et tableau de tarification',
    defaultTopic: 'Conception et déploiement d\'une plateforme web moderne et scalée',
  },
];

const THEME_COLORS: Array<{ id: 'blue' | 'emerald' | 'carbon' | 'purple'; label: string; bgClass: string }> = [
  { id: 'blue', label: 'Cobalt Tech', bgClass: 'bg-cyan-500' },
  { id: 'emerald', label: 'Émeraude Savoirs', bgClass: 'bg-emerald-500' },
  { id: 'carbon', label: 'Carbone Premium', bgClass: 'bg-slate-700' },
  { id: 'purple', label: 'Violet Nebula', bgClass: 'bg-purple-500' },
];

export function PdfStudio() {
  const [topic, setTopic] = useState('La mécanique quantique : Dualité onde-corpuscule et superposition');
  const [docType, setDocType] = useState('course_summary');
  const [level, setLevel] = useState('Université / Classes Préparatoires');
  const [author, setAuthor] = useState('NexusAI Studio & Recherche');
  const [selectedTheme, setSelectedTheme] = useState<'blue' | 'emerald' | 'carbon' | 'purple'>('blue');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const [currentDoc, setCurrentDoc] = useState<GeneratedPdfDoc>({
    id: 'doc-initial',
    title: 'Fiche Complète : La Mécanique Quantique & La Superposition',
    subtitle: 'Théorie fondamentale, formalisme de Dirac et applications technologiques',
    category: 'Sciences Physiques & Mathématiques',
    author: 'NexusAI Studio & Recherche',
    date: new Date().toLocaleDateString('fr-FR'),
    themeColor: 'blue',
    abstract: 'Cette fiche de synthèse présente les principes directeurs de la physique quantique : la quantification de l\'énergie selon Planck et Einstein, l\'équation de Schrödinger, et la superposition des états quantiques au cœur de l\'informatique quantique moderne.',
    sections: [
      {
        heading: '1. Les Postulats Fondamentaux & La Dualité Onde-Corpuscule',
        content: 'La mécanique quantique décrit le comportement de la matière à l\'échelle atomique. En 1924, Louis de Broglie postule que toute particule matérielle possède une longueur d\'onde associée λ = h / p, réconciliant corpuscule et onde.',
        bullets: [
          'Postulat 1 : L\'état d\'un système est représenté par un vecteur unitaire |ψ⟩ dans un espace de Hilbert.',
          'Postulat 2 : Toute grandeur physique mesurable est représentée par un opérateur hermitien A.',
          'Principe d\'incertitude d\'Heisenberg : Δx · Δp ≥ ℏ / 2.',
        ],
        callout: 'Formule clé : E = ℏω = hν (Relation de Planck-Einstein liant pulsation et énergie)',
      },
      {
        heading: '2. L\'Équation de Schrödinger & Calculs Matriciels',
        content: 'L\'évolution temporelle d\'un système quantique fermé non-relativiste est gouvernée par l\'équation différentielle de Schrödinger :',
        table: {
          headers: ['Grandeur Quantique', 'Opérateur Hermitien', 'Valeur Propre Observable'],
          rows: [
            ['Position x', 'X = x ·', 'Coordonnée spatiale (m)'],
            ['Quantité de mouvement p', 'P = -iℏ ∇', 'Momentum (kg·m/s)'],
            ['Énergie totale H', 'Hamiltonien H = T + V', 'Niveaux d\'énergie discrets En'],
          ],
        },
      },
      {
        heading: '3. Applications Contemporaines : De l\'Atome au Qubit',
        content: 'Les technologies quantiques de 2nde génération exploitent activement l\'intrication et la cohérence quantique. Les ordinateurs quantiques utilisent des qubits |ψ⟩ = α|0⟩ + β|1⟩ avec |α|² + |β|² = 1.',
        bullets: [
          'Cryptographie quantique (protocole BB84 à distribution de clés inviolable).',
          'Supraconducteurs et capteurs magnétiques à SQUID de précision atomique.',
          'Algorithme de Grover (recherche quadratique) et de Shor (factorisation exponentielle).',
        ],
        callout: 'À retenir : La mesure quantique provoque l\'effondrement irréversible du paquet d\'ondes vers un état propre.',
      },
    ],
  });

  // Handle AI generation of document
  const handleGenerateDoc = async () => {
    if (!topic.trim() || isGenerating) return;
    setIsGenerating(true);

    try {
      const res = await fetch('/api/ai/generate-document-structure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          docType,
          level,
          author,
        }),
      });

      const data = await res.json();
      if (data.success && data.document) {
        setCurrentDoc({
          ...data.document,
          themeColor: selectedTheme,
        });
      }
    } catch {
      // Local fallback document
      setCurrentDoc((prev) => ({
        ...prev,
        title: `Dossier d'Étude Approfondie : ${topic}`,
        subtitle: `Rédigé pour niveau ${level} - Validation technique`,
        themeColor: selectedTheme,
      }));
    } finally {
      setIsGenerating(false);
    }
  };

  // Download PDF
  const handleDownloadPdf = () => {
    setIsDownloading(true);
    try {
      const doc = buildPdfDocument({
        ...currentDoc,
        themeColor: selectedTheme,
      });
      const cleanFileName = currentDoc.title
        .toLowerCase()
        .replace(/[^a-z0-9]/gi, '_')
        .substring(0, 30);
      doc.save(`${cleanFileName || 'document'}_nexusai.pdf`);
    } catch (e) {
      console.error('PDF generation error:', e);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              GÉNÉRATEUR DE DOCUMENTS PDF
            </span>
            <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              EXPORT OFFICIEL A4 PRÊT À L'IMPRESSION
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white flex items-center gap-3">
            <FileText className="w-8 h-8 text-cyan-400" />
            Rédaction & Export PDF Automatique
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            L'IA conçoit des fiches de cours académiques, rapports techniques SRE, devis et synthèses professionnelles entièrement structurés et téléchargeables au format PDF.
          </p>
        </div>

        <button
          onClick={handleDownloadPdf}
          disabled={isDownloading}
          className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold text-sm shadow-xl shadow-cyan-500/25 transition-all self-start md:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>{isDownloading ? 'Génération du PDF...' : 'Télécharger le PDF (.pdf)'}</span>
        </button>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Form & Configuration */}
        <div className="lg:col-span-5 space-y-6">
          {/* Document Generation Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm space-y-4 shadow-xl">
            <div>
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                Sujet ou Thème du Document
              </label>
              <textarea
                rows={3}
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="Ex: Les équations de Maxwell et l'électromagnétisme, ou Audit d'une architecture micro-services..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition-colors resize-none"
              />
            </div>

            {/* Template Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-purple-400" />
                Type de Document & Structure
              </label>
              <div className="space-y-2">
                {TEMPLATES.map((tmpl) => {
                  const Icon = tmpl.icon;
                  return (
                    <button
                      key={tmpl.id}
                      onClick={() => {
                        setDocType(tmpl.id);
                        if (!topic || topic === TEMPLATES.find((t) => t.id === docType)?.defaultTopic) {
                          setTopic(tmpl.defaultTopic);
                        }
                      }}
                      className={`w-full flex items-start gap-3 p-3 rounded-xl border text-left transition-all ${
                        docType === tmpl.id
                          ? 'bg-cyan-950/40 border-cyan-500 text-white shadow-md'
                          : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className={`p-2 rounded-lg ${docType === tmpl.id ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">{tmpl.label}</div>
                        <div className="text-[11px] text-slate-500">{tmpl.desc}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Level & Author Fields */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">Niveau Cible</label>
                <select
                  value={level}
                  onChange={(e) => setLevel(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option>Collège / Brevet</option>
                  <option>Lycée / Bac Général & Tech</option>
                  <option>Université / Classes Préparatoires</option>
                  <option>Master / École d'Ingénieurs</option>
                  <option>Entreprise & Professionnel</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">Thème Visuel</label>
                <div className="flex gap-2 py-1">
                  {THEME_COLORS.map((th) => (
                    <button
                      key={th.id}
                      onClick={() => setSelectedTheme(th.id)}
                      className={`w-8 h-8 rounded-lg ${th.bgClass} flex items-center justify-center transition-all ${
                        selectedTheme === th.id ? 'ring-2 ring-white scale-110' : 'opacity-60 hover:opacity-100'
                      }`}
                      title={th.label}
                    >
                      {selectedTheme === th.id && <Check className="w-4 h-4 text-white" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerateDoc}
              disabled={isGenerating || !topic.trim()}
              className="w-full mt-3 py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:via-blue-500 hover:to-indigo-500 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Rédaction & Structuration IA...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Générer le Document avec l'IA</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Live Document Preview */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 backdrop-blur-sm shadow-2xl space-y-6">
            {/* Document Header Controls */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                <span className="text-xs font-bold text-slate-200">
                  Aperçu Conforme Page A4 ({currentDoc.sections.length} Sections)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    isEditing ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isEditing ? 'Mode Lecture' : 'Éditer le texte'}</span>
                </button>

                <button
                  onClick={handleDownloadPdf}
                  className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-extrabold flex items-center gap-1.5 shadow-md shadow-cyan-500/20 transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Exporter PDF</span>
                </button>
              </div>
            </div>

            {/* Document Sheet Simulation (A4 Look) */}
            <div className="bg-white text-slate-900 rounded-xl p-8 md:p-10 shadow-2xl border border-slate-300 space-y-6 max-h-[750px] overflow-y-auto selection:bg-cyan-200">
              {/* Top Accent Strip */}
              <div
                className={`h-2.5 w-full rounded-full ${
                  selectedTheme === 'emerald'
                    ? 'bg-emerald-600'
                    : selectedTheme === 'carbon'
                    ? 'bg-slate-800'
                    : selectedTheme === 'purple'
                    ? 'bg-purple-600'
                    : 'bg-cyan-600'
                }`}
              />

              {/* Category & Date */}
              <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
                <span>{currentDoc.category}</span>
                <span>{currentDoc.date}</span>
              </div>

              {/* Title & Subtitle */}
              <div>
                {isEditing ? (
                  <input
                    type="text"
                    value={currentDoc.title}
                    onChange={(e) => setCurrentDoc({ ...currentDoc, title: e.target.value })}
                    className="w-full text-2xl font-black text-slate-900 border-b border-cyan-500 pb-1 focus:outline-none"
                  />
                ) : (
                  <h2 className="text-2xl md:text-3xl font-black text-slate-900 leading-tight">
                    {currentDoc.title}
                  </h2>
                )}

                {isEditing ? (
                  <input
                    type="text"
                    value={currentDoc.subtitle}
                    onChange={(e) => setCurrentDoc({ ...currentDoc, subtitle: e.target.value })}
                    className="w-full text-sm italic text-slate-600 mt-2 border-b border-slate-300 focus:outline-none"
                  />
                ) : (
                  <p className="text-sm italic text-slate-600 mt-1 font-medium">{currentDoc.subtitle}</p>
                )}

                <div className="text-xs text-slate-400 mt-2">
                  Document élaboré par : <span className="font-semibold text-slate-700">{currentDoc.author}</span>
                </div>
              </div>

              {/* Abstract Callout */}
              {currentDoc.abstract && (
                <div
                  className={`p-4 rounded-xl border-l-4 text-xs leading-relaxed ${
                    selectedTheme === 'emerald'
                      ? 'bg-emerald-50 border-emerald-600 text-emerald-950'
                      : selectedTheme === 'carbon'
                      ? 'bg-slate-100 border-slate-700 text-slate-900'
                      : selectedTheme === 'purple'
                      ? 'bg-purple-50 border-purple-600 text-purple-950'
                      : 'bg-cyan-50 border-cyan-600 text-cyan-950'
                  }`}
                >
                  <span className="font-bold uppercase tracking-wider block mb-1">Résumé Exécutif :</span>
                  {isEditing ? (
                    <textarea
                      rows={2}
                      value={currentDoc.abstract}
                      onChange={(e) => setCurrentDoc({ ...currentDoc, abstract: e.target.value })}
                      className="w-full bg-transparent border-b border-slate-400 focus:outline-none"
                    />
                  ) : (
                    <p>{currentDoc.abstract}</p>
                  )}
                </div>
              )}

              {/* Sections */}
              <div className="space-y-6 pt-2">
                {currentDoc.sections.map((sec, idx) => (
                  <div key={idx} className="space-y-3 pb-4 border-b border-slate-100 last:border-b-0">
                    <h3
                      className={`text-base font-bold ${
                        selectedTheme === 'emerald'
                          ? 'text-emerald-800'
                          : selectedTheme === 'carbon'
                          ? 'text-slate-900'
                          : selectedTheme === 'purple'
                          ? 'text-purple-800'
                          : 'text-cyan-800'
                      }`}
                    >
                      {sec.heading}
                    </h3>

                    <p className="text-xs leading-relaxed text-slate-700 font-normal">
                      {sec.content}
                    </p>

                    {/* Bullets */}
                    {sec.bullets && sec.bullets.length > 0 && (
                      <ul className="space-y-1.5 pl-4">
                        {sec.bullets.map((b, bIdx) => (
                          <li key={bIdx} className="text-xs text-slate-700 flex items-start gap-2">
                            <span
                              className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                                selectedTheme === 'emerald'
                                  ? 'bg-emerald-600'
                                  : selectedTheme === 'carbon'
                                  ? 'bg-slate-700'
                                  : selectedTheme === 'purple'
                                  ? 'bg-purple-600'
                                  : 'bg-cyan-600'
                              }`}
                            />
                            <span>{b}</span>
                          </li>
                        ))}
                      </ul>
                    )}

                    {/* Callout */}
                    {sec.callout && (
                      <div
                        className={`p-3 rounded-lg border-l-4 text-xs font-semibold ${
                          selectedTheme === 'emerald'
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-900'
                            : selectedTheme === 'carbon'
                            ? 'bg-slate-100 border-slate-600 text-slate-800'
                            : selectedTheme === 'purple'
                            ? 'bg-purple-50 border-purple-500 text-purple-900'
                            : 'bg-cyan-50 border-cyan-500 text-cyan-900'
                        }`}
                      >
                        {sec.callout}
                      </div>
                    )}

                    {/* Table */}
                    {sec.table && (
                      <div className="overflow-x-auto rounded-lg border border-slate-200 mt-2">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                            <tr>
                              {sec.table.headers.map((h, hIdx) => (
                                <th key={hIdx} className="p-2.5">
                                  {h}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {sec.table.rows.map((row, rIdx) => (
                              <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                                {row.map((cell, cIdx) => (
                                  <td key={cIdx} className="p-2.5 text-slate-600 font-mono text-[11px]">
                                    {cell}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Sheet Footer */}
              <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-400">
                <span>NexusAI Intelligence Studio • Document Certifié Conforme</span>
                <span>Page 1 / 1</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

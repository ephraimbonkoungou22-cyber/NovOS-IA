import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Activity, 
  Zap, 
  Globe, 
  Cpu, 
  HardDrive, 
  ShieldCheck, 
  TrendingUp, 
  Clock, 
  Users, 
  Server,
  ArrowUpRight
} from 'lucide-react';

interface AnalyticsProps {
  liveRps: number;
}

export const AnalyticsDashboard: React.FC<AnalyticsProps> = ({ liveRps }) => {
  const [timeRange, setTimeRange] = useState<'1h' | '6h' | '24h' | '7d'>('1h');
  const [dataPoints, setDataPoints] = useState<number[]>([
    1750, 1820, 1910, 1840, 1960, 2040, 1980, 2120, 2080, 2190, 2240, 2150, 2300, 2280, 2390, liveRps
  ]);

  // Update chart periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setDataPoints((prev) => {
        const next = [...prev.slice(1)];
        const variation = Math.floor(Math.random() * 80) - 40;
        next.push(Math.max(1600, liveRps + variation));
        return next;
      });
    }, 2000);
    return () => clearInterval(interval);
  }, [liveRps]);

  const maxVal = Math.max(...dataPoints, 2600);

  const services = [
    { name: 'Moteur Gemini 3.8 Inférence', status: 'Optimal', latency: '18ms', uptime: '100%' },
    { name: 'Passerelle API Anycast Envoy', status: 'Optimal', latency: '3ms', uptime: '99.999%' },
    { name: 'Cache Mémoire Redis Cluster', status: 'Optimal', latency: '0.8ms', uptime: '100%' },
    { name: 'Base PostgreSQL Multi-AZ', status: 'Optimal', latency: '6ms', uptime: '99.998%' },
    { name: 'Pipeline CI/CD Déploiement', status: 'Optimal', latency: '42ms', uptime: '100%' },
    { name: 'Pare-Feu Applicatif WAF L7', status: 'Optimal', latency: '1.2ms', uptime: '100%' },
  ];

  return (
    <div className="h-full flex flex-col p-4 lg:p-6 max-w-7xl mx-auto w-full space-y-6 overflow-y-auto">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-cyan-950/70 via-slate-900 to-indigo-950/60 border border-cyan-500/20 p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                <BarChart3 className="w-4 h-4 text-cyan-400" />
              </span>
              <span className="text-xs font-mono font-semibold tracking-wider uppercase text-cyan-400">
                Monitoring SRE & Télémétrie en Direct
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Tableau de Bord Analytique Global
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl mt-1 leading-relaxed">
              Supervision de l'activité du système en temps réel : débit de requêtes, latence p99, disponibilité des microservices et allocation de ressources.
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/90 p-1 rounded-xl border border-slate-800 text-xs">
            {(['1h', '6h', '24h', '7d'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setTimeRange(r)}
                className={`px-3 py-1.5 rounded-lg font-mono font-medium transition-colors ${
                  timeRange === r
                    ? 'bg-cyan-500 text-white font-bold shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Débit Global (Throughput)</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">{liveRps.toLocaleString()} <span className="text-xs text-slate-400 font-normal">req/s</span></div>
          <div className="text-xs text-emerald-400 font-medium flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> +14.2% vs semaine dernière
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Latence p99 Globale</span>
            <Zap className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">18.4 ms</div>
          <div className="text-xs text-slate-400">
            p50: 9.1ms • p95: 14.2ms
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Disponibilité SLA</span>
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">99.998%</div>
          <div className="text-xs text-emerald-400 font-mono">Zero Downtime sur 90j</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Taux d'Erreurs 5xx</span>
            <Server className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-black text-cyan-300 font-mono">0.0004%</div>
          <div className="text-xs text-slate-400 font-mono">4 échecs sur 1,000,000 req</div>
        </div>
      </div>

      {/* Main Dynamic Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Volume des Requêtes & Inférences en Temps Réel</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">Échantillonné toutes les secondes sur l'ensemble des clusters</p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="flex items-center gap-1 text-cyan-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
              Live Stream
            </span>
          </div>
        </div>

        {/* Dynamic SVG / Bar Graph */}
        <div className="h-60 flex items-end gap-2 pt-6 px-2">
          {dataPoints.map((val, idx) => {
            const heightPct = Math.round((val / maxVal) * 100);
            return (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1 group relative">
                {/* Tooltip on hover */}
                <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 bg-slate-950 text-cyan-300 text-[10px] font-mono px-2 py-0.5 rounded border border-slate-800 pointer-events-none whitespace-nowrap z-10">
                  {val.toLocaleString()} req/s
                </div>

                <div
                  className="w-full bg-gradient-to-t from-cyan-600 via-indigo-600 to-purple-500 rounded-t transition-all duration-300 group-hover:brightness-125"
                  style={{ height: `${heightPct}%` }}
                ></div>
                <span className="text-[9px] font-mono text-slate-500 group-hover:text-slate-300">
                  {idx === dataPoints.length - 1 ? 'Now' : `-${(dataPoints.length - 1 - idx) * 2}s`}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Microservices Health Table & Regional Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Services table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <h2 className="text-sm font-bold text-white">Statut des Microservices & Dépendances</h2>
          <div className="space-y-2">
            {services.map((srv, i) => (
              <div
                key={i}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs hover:border-slate-700 transition-all"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="font-semibold text-slate-200">{srv.name}</span>
                </div>

                <div className="flex items-center gap-4 font-mono text-slate-400">
                  <span>Latence : <strong className="text-cyan-400">{srv.latency}</strong></span>
                  <span>Uptime : <strong className="text-emerald-400">{srv.uptime}</strong></span>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                    {srv.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Regional traffic breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-blue-400" />
            <span>Distribution Géographique</span>
          </h2>

          <div className="space-y-3 text-xs">
            {[
              { region: 'Europe (eu-west3, eu-west1)', pct: 44, color: 'bg-cyan-500' },
              { region: 'Amérique du Nord (us-east1, us-west1)', pct: 36, color: 'bg-indigo-500' },
              { region: 'Asie-Pacifique (asia-east1, ap-south1)', pct: 16, color: 'bg-purple-500' },
              { region: 'Autres régions (latam, africa)', pct: 4, color: 'bg-teal-500' },
            ].map((r, i) => (
              <div key={i} className="space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span>{r.region}</span>
                  <span className="font-mono font-bold text-cyan-400">{r.pct}%</span>
                </div>
                <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                  <div className={`${r.color} h-full rounded-full`} style={{ width: `${r.pct}%` }}></div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1">
            <div className="font-semibold text-slate-200">Routage BGP & Anycast Optimisé</div>
            <p>99.4% des utilisateurs servis sous 25 millisecondes depuis le PoP le plus proche.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { GeneratedImage } from '../types';
import {
  Sparkles,
  Download,
  Image as ImageIcon,
  Wand2,
  Maximize2,
  RefreshCw,
  Layers,
  FileText,
  Sliders,
  Copy,
  Check,
  Palette,
  Eye,
  Camera,
} from 'lucide-react';

interface ImageStudioProps {
  onExportToPdf?: (imageUrl: string, prompt: string) => void;
}

const STYLE_PRESETS = [
  { id: 'photorealistic', label: 'Photoréaliste 8K', icon: '📸', desc: 'Hasselblad 85mm f/1.4, raytracing, éclairage cinématique' },
  { id: 'cyberpunk', label: 'Cyberpunk Néon', icon: '🌌', desc: 'Néons turquoise et magenta, reflets asphalte humide' },
  { id: 'anime', label: 'Anime & Ghibli', icon: '🎨', desc: 'Style Makoto Shinkai, ciel vibrant, poésie visuelle' },
  { id: 'c4d_3d', label: 'Rendu 3D Octane', icon: '🧊', desc: 'Cinema 4D, subsurface scattering, argile et verre' },
  { id: 'oil_painting', label: 'Peinture à l\'Huile', icon: '🖌️', desc: 'Empâtement au couteau, clair-obscur Rembrandt' },
  { id: 'isometric', label: 'Vectoriel Isométrique', icon: '📐', desc: 'Perspective isométrique propre, design produit' },
  { id: 'architecture', label: 'Architecture Moderne', icon: '🏛️', desc: 'Béton brut, verre courbé, lumière dorée' },
];

const ASPECT_RATIOS = [
  { id: '1:1', label: '1:1 Carré', width: 1024, height: 1024, iconClass: 'w-5 h-5 border border-current rounded-sm' },
  { id: '16:9', label: '16:9 Cinéma', width: 1280, height: 720, iconClass: 'w-6 h-3.5 border border-current rounded-sm' },
  { id: '9:16', label: '9:16 Portrait', width: 720, height: 1280, iconClass: 'w-3.5 h-6 border border-current rounded-sm' },
  { id: '4:3', label: '4:3 Standard', width: 1024, height: 768, iconClass: 'w-5 h-4 border border-current rounded-sm' },
];

const PROMPT_SUGGESTIONS = [
  'Un astronaute contemplant une nébuleuse pourpre depuis une station orbitale en verre',
  'Une bibliothèque cyberpunk lumineuse enfouie dans un sanctuaire de cristal et de verdure',
  'Un renard mystique aux yeux d\'or marchant sur un lac gelé sous une aurore boréale éclatante',
  'Une ville flottante futuriste alimentée par des cascades d\'énergie solaire au coucher du soleil',
  'Un laboratoire d\'alchimie et d\'informatique quantique avec des hologrammes et des sphères de plasma',
];

export function ImageStudio({ onExportToPdf }: ImageStudioProps) {
  const [prompt, setPrompt] = useState('Une cité futuriste bioluminescente suspendue au-dessus d\'un océan de nuages dorés au crépuscule');
  const [selectedStyle, setSelectedStyle] = useState('photorealistic');
  const [selectedRatio, setSelectedRatio] = useState('1:1');
  const [engineMode, setEngineMode] = useState<'diffusion' | 'procedural'>('diffusion');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [enhancedPrompt, setEnhancedPrompt] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [currentImage, setCurrentImage] = useState<GeneratedImage | null>(null);
  const [gallery, setGallery] = useState<GeneratedImage[]>([]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Initial seed generation
  useEffect(() => {
    generateInitialProceduralArt('Une cité futuriste bioluminescente au crépuscule', 'photorealistic', '1:1');
  }, []);

  // AI Prompt Enhancer
  const handleEnhancePrompt = async () => {
    if (!prompt.trim() || isEnhancing) return;
    setIsEnhancing(true);

    try {
      const res = await fetch('/api/ai/enhance-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          style: selectedStyle,
          aspectRatio: selectedRatio,
        }),
      });
      const data = await res.json();
      if (data.success && data.enhancedPrompt) {
        setEnhancedPrompt(data.enhancedPrompt);
      }
    } catch {
      // Fallback local enhancement
      setEnhancedPrompt(`Ultra high-resolution masterpiece: ${prompt.trim()}, ${selectedStyle} style, 8k resolution, dramatic volumetric lighting, cinematic color grading, raytraced reflections.`);
    } finally {
      setIsEnhancing(false);
    }
  };

  // Generate Procedural Generative Art on HTML5 Canvas
  const generateProceduralArt = (promptText: string, style: string, ratio: string): string => {
    const canvas = document.createElement('canvas');
    const ratioObj = ASPECT_RATIOS.find((r) => r.id === ratio) || ASPECT_RATIOS[0];
    canvas.width = ratioObj.width;
    canvas.height = ratioObj.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    const w = canvas.width;
    const h = canvas.height;

    // Pseudo-random deterministic hash from prompt
    let seed = 0;
    for (let i = 0; i < promptText.length; i++) {
      seed = (seed * 31 + promptText.charCodeAt(i)) % 100000;
    }
    const rand = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };

    // Color palettes based on style
    let colorA = '#0f172a';
    let colorB = '#1e293b';
    let accent1 = '#06b6d4';
    let accent2 = '#3b82f6';
    let glow = '#38bdf8';

    if (style === 'cyberpunk') {
      colorA = '#0a051b';
      colorB = '#1f0d3d';
      accent1 = '#ec4899';
      accent2 = '#06b6d4';
      glow = '#f43f5e';
    } else if (style === 'anime') {
      colorA = '#172554';
      colorB = '#3b82f6';
      accent1 = '#fbbf24';
      accent2 = '#f472b6';
      glow = '#60a5fa';
    } else if (style === 'c4d_3d') {
      colorA = '#18181b';
      colorB = '#3f3f46';
      accent1 = '#8b5cf6';
      accent2 = '#10b981';
      glow = '#c084fc';
    } else if (style === 'oil_painting') {
      colorA = '#1c1917';
      colorB = '#44403c';
      accent1 = '#d97706';
      accent2 = '#b45309';
      glow = '#f59e0b';
    }

    // 1. Background gradient
    const bgGrad = ctx.createLinearGradient(0, 0, w, h);
    bgGrad.addColorStop(0, colorA);
    bgGrad.addColorStop(0.5, colorB);
    bgGrad.addColorStop(1, '#020617');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // 2. Celestial sphere / Ambient Orb
    const orbX = w * (0.3 + rand() * 0.4);
    const orbY = h * (0.2 + rand() * 0.3);
    const orbRadius = Math.min(w, h) * (0.15 + rand() * 0.2);

    const orbGrad = ctx.createRadialGradient(orbX, orbY, orbRadius * 0.1, orbX, orbY, orbRadius * 1.5);
    orbGrad.addColorStop(0, glow);
    orbGrad.addColorStop(0.4, accent1);
    orbGrad.addColorStop(0.8, 'rgba(6, 182, 212, 0.1)');
    orbGrad.addColorStop(1, 'transparent');

    ctx.fillStyle = orbGrad;
    ctx.beginPath();
    ctx.arc(orbX, orbY, orbRadius * 1.5, 0, Math.PI * 2);
    ctx.fill();

    // 3. Volumetric Horizon Layers (Mountains / Futuristic Skyline)
    const layersCount = 5;
    for (let l = 0; l < layersCount; l++) {
      const layerY = h * (0.5 + (l / layersCount) * 0.45);
      const alpha = 0.2 + (l / layersCount) * 0.8;

      ctx.fillStyle = l === layersCount - 1 ? '#030712' : `rgba(15, 23, 42, ${alpha})`;
      ctx.beginPath();
      ctx.moveTo(0, h);
      ctx.lineTo(0, layerY);

      const segments = 16;
      for (let s = 1; s <= segments; s++) {
        const segX = (w / segments) * s;
        const wave = Math.sin(s * 0.8 + l + rand() * 2) * (h * 0.08);
        const segY = layerY + wave;
        ctx.lineTo(segX, segY);
      }

      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fill();

      // Atmospheric edge highlight
      ctx.strokeStyle = `rgba(56, 189, 248, ${0.15 + (1 - l / layersCount) * 0.3})`;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // 4. City Spire / Geometry Nodes
    const spires = 8 + Math.floor(rand() * 8);
    for (let s = 0; s < spires; s++) {
      const spireX = w * (0.1 + rand() * 0.8);
      const spireWidth = 10 + rand() * 35;
      const spireHeight = h * (0.15 + rand() * 0.45);
      const spireY = h - spireHeight;

      const spireGrad = ctx.createLinearGradient(spireX, spireY, spireX + spireWidth, h);
      spireGrad.addColorStop(0, 'rgba(15, 23, 42, 0.95)');
      spireGrad.addColorStop(1, '#020617');

      ctx.fillStyle = spireGrad;
      ctx.fillRect(spireX, spireY, spireWidth, spireHeight);

      // Neon window grid
      ctx.fillStyle = rand() > 0.5 ? accent1 : accent2;
      for (let wy = spireY + 15; wy < h - 40; wy += 12) {
        if (rand() > 0.4) {
          ctx.fillRect(spireX + 3, wy, 3, 5);
        }
        if (rand() > 0.4 && spireWidth > 18) {
          ctx.fillRect(spireX + spireWidth - 6, wy, 3, 5);
        }
      }

      // Spire tip laser/beacon
      ctx.strokeStyle = glow;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(spireX + spireWidth / 2, spireY);
      ctx.lineTo(spireX + spireWidth / 2, spireY - 25);
      ctx.stroke();
    }

    // 5. Particle Stardust
    const particleCount = 120;
    for (let p = 0; p < particleCount; p++) {
      const px = rand() * w;
      const py = rand() * h;
      const pSize = 1 + rand() * 2.5;
      const pAlpha = 0.2 + rand() * 0.8;

      ctx.fillStyle = p % 2 === 0 ? `rgba(255, 255, 255, ${pAlpha})` : `rgba(56, 189, 248, ${pAlpha})`;
      ctx.beginPath();
      ctx.arc(px, py, pSize, 0, Math.PI * 2);
      ctx.fill();
    }

    // 6. Watermark / Subtle Studio Badge
    ctx.font = '600 14px sans-serif';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.fillText('NEXUS AI • NEURAL VISUAL ENGINE 4K', 30, h - 30);

    return canvas.toDataURL('image/png');
  };

  const generateInitialProceduralArt = (pText: string, style: string, ratio: string) => {
    const dataUrl = generateProceduralArt(pText, style, ratio);
    const initialImg: GeneratedImage = {
      id: 'img-' + Date.now(),
      prompt: pText,
      enhancedPrompt: 'A breathtaking futuristic bioluminescent metropolis hanging above an ocean of golden sunset clouds, Hasselblad 85mm f/1.4, volumetric god rays, octane render 8k.',
      style,
      aspectRatio: ratio,
      imageUrl: dataUrl,
      sourceType: 'procedural_vector',
      createdAt: 'À l\'instant',
    };
    setCurrentImage(initialImg);
    setGallery([initialImg]);
  };

  // Main Generation Handler
  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;
    setIsGenerating(true);

    try {
      // 1. First get enhanced prompt if not already present
      let effectivePrompt = enhancedPrompt;
      if (!effectivePrompt) {
        try {
          const res = await fetch('/api/ai/enhance-prompt', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              prompt: prompt.trim(),
              style: selectedStyle,
              aspectRatio: selectedRatio,
            }),
          });
          const data = await res.json();
          if (data.success && data.enhancedPrompt) {
            effectivePrompt = data.enhancedPrompt;
            setEnhancedPrompt(effectivePrompt);
          }
        } catch {
          effectivePrompt = prompt.trim();
        }
      }

      // 2. Engine generation
      let finalImageUrl = '';
      let sourceType: 'diffusion' | 'procedural_vector' = engineMode;

      if (engineMode === 'diffusion') {
        const ratioObj = ASPECT_RATIOS.find((r) => r.id === selectedRatio) || ASPECT_RATIOS[0];
        const queryPrompt = encodeURIComponent(effectivePrompt || prompt);
        const seed = Math.floor(Math.random() * 999999);
        // High fidelity Pollinations AI URL (Flux / SDXL model)
        finalImageUrl = `https://image.pollinations.ai/prompt/${queryPrompt}?width=${ratioObj.width}&height=${ratioObj.height}&seed=${seed}&nologo=true&enhance=false`;

        // Preload image to verify availability
        await new Promise((resolve) => {
          const img = new Image();
          img.onload = () => resolve(true);
          img.onerror = () => {
            // Fallback to high resolution procedural canvas
            finalImageUrl = generateProceduralArt(effectivePrompt || prompt, selectedStyle, selectedRatio);
            sourceType = 'procedural_vector';
            resolve(true);
          };
          img.src = finalImageUrl;
          // Timeout to avoid infinite loading
          setTimeout(() => {
            if (!img.complete) {
              finalImageUrl = generateProceduralArt(effectivePrompt || prompt, selectedStyle, selectedRatio);
              sourceType = 'procedural_vector';
              resolve(true);
            }
          }, 8000);
        });
      } else {
        finalImageUrl = generateProceduralArt(effectivePrompt || prompt, selectedStyle, selectedRatio);
      }

      const newImage: GeneratedImage = {
        id: 'img-' + Date.now(),
        prompt: prompt.trim(),
        enhancedPrompt: effectivePrompt || undefined,
        style: selectedStyle,
        aspectRatio: selectedRatio,
        imageUrl: finalImageUrl,
        sourceType,
        createdAt: 'À l\'instant',
      };

      setCurrentImage(newImage);
      setGallery((prev) => [newImage, ...prev.slice(0, 11)]);
    } catch {
      // In case of any network error, guarantee stunning procedural output
      const fallbackUrl = generateProceduralArt(prompt, selectedStyle, selectedRatio);
      const fallbackImg: GeneratedImage = {
        id: 'img-' + Date.now(),
        prompt: prompt.trim(),
        style: selectedStyle,
        aspectRatio: selectedRatio,
        imageUrl: fallbackUrl,
        sourceType: 'procedural_vector',
        createdAt: 'À l\'instant',
      };
      setCurrentImage(fallbackImg);
      setGallery((prev) => [fallbackImg, ...prev]);
    } finally {
      setIsGenerating(false);
    }
  };

  // Download Image
  const handleDownload = () => {
    if (!currentImage) return;
    const a = document.createElement('a');
    a.href = currentImage.imageUrl;
    a.download = `nexusai-${currentImage.style}-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const copyPromptText = () => {
    if (!currentImage) return;
    navigator.clipboard.writeText(currentImage.enhancedPrompt || currentImage.prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              STUDIO CRÉATIF UNIVERSEL
            </span>
            <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/30">
              RÉSOLUTIONS 4K & FLUX
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white flex items-center gap-3">
            <ImageIcon className="w-8 h-8 text-cyan-400" />
            Génération Visuelle & Artistique IA
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Créez des illustrations ultra-réalistes, des concepts futuristes, des rendus 3D et des graphismes de haute précision à partir de n'importe quelle description.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setEngineMode('diffusion')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                engineMode === 'diffusion'
                  ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Diffusion Neuronal (Flux / SDXL)
            </button>
            <button
              onClick={() => setEngineMode('procedural')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                engineMode === 'procedural'
                  ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Canvas Procédural 4K (Zero-Latence)
            </button>
          </div>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Prompting & Controls */}
        <div className="lg:col-span-5 space-y-6">
          {/* Prompt Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-cyan-400" />
                Description Visuelle (Prompt)
              </label>
              <button
                onClick={handleEnhancePrompt}
                disabled={isEnhancing || !prompt.trim()}
                className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg bg-cyan-950/60 text-cyan-400 border border-cyan-800/60 hover:bg-cyan-900/50 transition-all disabled:opacity-50"
              >
                <Sparkles className={`w-3.5 h-3.5 ${isEnhancing ? 'animate-spin' : ''}`} />
                {isEnhancing ? 'Enrichissement...' : 'Améliorer avec l\'IA'}
              </button>
            </div>

            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => {
                setPrompt(e.target.value);
                setEnhancedPrompt(null);
              }}
              placeholder="Ex: Un renard néon au sommet d'une tour cybernétique sous la pluie..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition-colors resize-none"
            />

            {/* Quick Inspiration Pills */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-medium text-slate-500">Idées rapides :</span>
              <div className="flex flex-wrap gap-1.5">
                {PROMPT_SUGGESTIONS.slice(0, 3).map((sug, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setPrompt(sug);
                      setEnhancedPrompt(null);
                    }}
                    className="text-[11px] text-slate-400 hover:text-cyan-300 bg-slate-950 hover:bg-slate-800 px-2 py-1 rounded-md border border-slate-800 transition-colors text-left truncate max-w-[280px]"
                  >
                    "{sug.substring(0, 36)}..."
                  </button>
                ))}
              </div>
            </div>

            {/* Enhanced Prompt Preview if active */}
            {enhancedPrompt && (
              <div className="bg-cyan-950/30 border border-cyan-500/30 rounded-xl p-3 text-xs space-y-1 animate-fadeIn">
                <div className="flex items-center justify-between text-[11px] text-cyan-400 font-bold">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Prompt IA Optimisé
                  </span>
                  <button
                    onClick={() => setEnhancedPrompt(null)}
                    className="text-slate-500 hover:text-slate-300"
                  >
                    Effacer
                  </button>
                </div>
                <p className="text-slate-300 italic text-[11.5px] leading-relaxed line-clamp-3">
                  "{enhancedPrompt}"
                </p>
              </div>
            )}

            {/* Style Selector */}
            <div className="space-y-2 pt-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Palette className="w-4 h-4 text-purple-400" />
                Style Artistique
              </label>
              <div className="grid grid-cols-2 gap-2">
                {STYLE_PRESETS.map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setSelectedStyle(st.id)}
                    className={`flex items-start gap-2.5 p-2.5 rounded-xl border text-left transition-all ${
                      selectedStyle === st.id
                        ? 'bg-cyan-950/40 border-cyan-500 text-white shadow-lg shadow-cyan-950/20'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-lg">{st.icon}</span>
                    <div className="overflow-hidden">
                      <div className="text-xs font-bold text-white truncate">{st.label}</div>
                      <div className="text-[10px] text-slate-500 truncate">{st.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio Selector */}
            <div className="space-y-2 pt-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-400" />
                Format & Proportions
              </label>
              <div className="grid grid-cols-4 gap-2">
                {ASPECT_RATIOS.map((ratio) => (
                  <button
                    key={ratio.id}
                    onClick={() => setSelectedRatio(ratio.id)}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl border text-center transition-all ${
                      selectedRatio === ratio.id
                        ? 'bg-emerald-950/40 border-emerald-500 text-white'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className={`mb-1.5 flex items-center justify-center ${ratio.iconClass} ${selectedRatio === ratio.id ? 'border-emerald-400 text-emerald-400' : 'border-slate-500'}`} />
                    <span className="text-[11px] font-bold">{ratio.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Generate Action Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="w-full mt-4 py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:via-blue-500 hover:to-indigo-500 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Synthèse Neuronal en cours...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Générer l'Œuvre Visuelle</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Visual Preview & Canvas */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm shadow-xl space-y-4">
            {/* Action Bar */}
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-bold text-slate-200">
                  {currentImage ? `Aperçu Rendu 4K (${currentImage.aspectRatio})` : 'Zone de Rendu'}
                </span>
                {currentImage && (
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 font-mono">
                    {currentImage.sourceType === 'diffusion' ? 'Neural Diffusion' : 'Canvas Vectoriel'}
                  </span>
                )}
              </div>

              {currentImage && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={copyPromptText}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors text-xs flex items-center gap-1.5"
                    title="Copier le prompt"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>

                  {onExportToPdf && (
                    <button
                      onClick={() => onExportToPdf(currentImage.imageUrl, currentImage.prompt)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-950/60 text-indigo-400 border border-indigo-800/60 hover:bg-indigo-900/50 text-xs font-semibold transition-all"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Intégrer dans un PDF</span>
                    </button>
                  )}

                  <button
                    onClick={handleDownload}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-extrabold transition-all shadow-md shadow-cyan-500/20"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Télécharger HD</span>
                  </button>
                </div>
              )}
            </div>

            {/* Image Canvas / Viewer */}
            <div className="relative min-h-[380px] md:min-h-[460px] bg-slate-950 rounded-xl border border-slate-800/80 flex items-center justify-center overflow-hidden group">
              {isGenerating && (
                <div className="absolute inset-0 z-20 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center gap-3">
                  <div className="relative w-16 h-16">
                    <div className="absolute inset-0 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                    <Sparkles className="absolute inset-0 m-auto w-6 h-6 text-cyan-400 animate-pulse" />
                  </div>
                  <span className="text-sm font-bold text-white">Calcul des tenseurs de diffusion...</span>
                  <span className="text-xs text-slate-400">Application du style {selectedStyle}</span>
                </div>
              )}

              {currentImage ? (
                <img
                  src={currentImage.imageUrl}
                  alt={currentImage.prompt}
                  className="max-h-[500px] w-auto max-w-full object-contain rounded-lg shadow-2xl transition-transform duration-300 group-hover:scale-[1.01]"
                />
              ) : (
                <div className="text-center p-8 space-y-3">
                  <Camera className="w-12 h-12 text-slate-700 mx-auto" />
                  <p className="text-sm text-slate-400">Aucune image active. Tapez un prompt et cliquez sur Générer.</p>
                </div>
              )}
            </div>

            {/* Current Details */}
            {currentImage && (
              <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-4 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="font-semibold text-white">Sujet d'origine :</span>
                  <span>{currentImage.createdAt}</span>
                </div>
                <p className="text-slate-300 font-medium">"{currentImage.prompt}"</p>
                {currentImage.enhancedPrompt && (
                  <div className="pt-2 border-t border-slate-800">
                    <span className="text-cyan-400 font-semibold block mb-0.5">Prompt enrichi pour l'IA :</span>
                    <p className="text-slate-400 text-[11px] leading-relaxed line-clamp-2">
                      {currentImage.enhancedPrompt}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Previous Generations Gallery */}
          {gallery.length > 1 && (
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 backdrop-blur-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5 uppercase tracking-wider">
                  <Layers className="w-4 h-4 text-cyan-400" />
                  Historique de vos Créations ({gallery.length})
                </span>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2.5">
                {gallery.map((img) => (
                  <div
                    key={img.id}
                    onClick={() => setCurrentImage(img)}
                    className={`relative aspect-square rounded-xl overflow-hidden border cursor-pointer group transition-all ${
                      currentImage?.id === img.id
                        ? 'border-cyan-400 ring-2 ring-cyan-500/30'
                        : 'border-slate-800 hover:border-slate-600'
                    }`}
                  >
                    <img
                      src={img.imageUrl}
                      alt={img.prompt}
                      className="w-full h-full object-cover transition-transform group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Eye className="w-4 h-4 text-white" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
